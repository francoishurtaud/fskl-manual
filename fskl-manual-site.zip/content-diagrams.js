(function(){
var L=function(e,f){return {en:e,fr:f}};
var R='assets/raw/', C='assets/crop/';
window.FSKL_PATCH={
 '1-1':{blocks:[
  {w:[7,5], cols:[[
   {t:'lead', text:L('FSKL, Lycée Français de Kuala Lumpur is an international French school accredited by the AEFE, serving children from maternelle through the baccalauréat.','FSKL, Lycée Français de Kuala Lumpur, est un établissement français international homologué par l’AEFE, qui accueille les élèves de la maternelle au baccalauréat.')},
   {t:'p', text:L('It operates on the Henri Fauconnier Campus and runs two named programmes alongside its core French curriculum: the Eurocampus, a tricultural European framework bringing French, German, and English traditions onto one site, and HEVEA, the early-years programme where roots are first put down.','Installé sur le campus Henri Fauconnier, l’établissement déploie deux programmes nommés aux côtés du Programme officiel de l’Éducation nationale française : l’Eurocampus, cadre européen triculturel réunissant les traditions française, allemande et anglaise sur un même site, et HEVEA, le programme des premières années, là où les racines se posent.')},
   {t:'stats', items:[{big:'1962', text:L('Established · Kuala Lumpur','Création · Kuala Lumpur')},{img:'assets/logo/aefe-transparent.png', text:L('AEFE-accredited','Homologué AEFE')}]}
  ],[
   {t:'venn', center:L('3 traditions · 1 campus','3 traditions · 1 campus'), items:[{title:L('French','Française')},{title:L('German','Allemande')},{title:L('English','Anglaise')}]},
   {t:'note', text:L('European traditions. One campus: the Eurocampus.','Traditions européennes. Un seul campus : l’Eurocampus.')}
  ]]}
 ]},
 '1-2':{blocks:[
  {t:'table', head:[L('Level','Niveau'), L('Name','Nom'), L('Job','Rôle')], rows:[
   [L('1 · Brand Pictogram','1 · Pictogramme de marque'), {imgs:['assets/logo/fav.png']}, L('Visual, graphic representation of the school, used for Favicon too','Représentation visuelle et graphique de l’école, utilisée aussi pour le favicon')],
   [L('2 · Institutional name','2 · Nom institutionnel'), {imgs:['assets/logo/types-institutional.png']}, L('The full institutional name. Legal, formal, and never translated.','Le nom institutionnel complet. Juridique, formel, et jamais traduit.')],
   [L('3 · The place','3 · Le lieu'), L('Henri Fauconnier Campus','Campus Henri Fauconnier'), L('Named for the planter and Goncourt laureate who linked France to Malaya.','Nommé en référence au planteur et prix Goncourt qui relia la France à la Malaisie.')],
   [L('4 · The programmes','4 · Les programmes'), L('Eurocampus\nHEVEA','Eurocampus\nHEVEA'), L('Eurocampus carries the tricultural ambition; HEVEA carries the early years.','L’Eurocampus porte l’ambition triculturelle ; HEVEA porte les premières années.')]]}
 ]},
 '1-3':{prepend:[
  {t:'timeline', items:[
   {year:'1879', title:L('Henri Fauconnier is born','Naissance d’Henri Fauconnier')},
   {year:L('Early 1900s','Début du XXe s.'), title:L('Pioneers rubber plantations in Selangor','Développe les plantations d’hévéas au Selangor')},
   {year:'1930', title:L('Prix Goncourt for his novel Malaisie','Prix Goncourt pour son roman Malaisie')},
   {year:'1962', title:L('A French school opens in Kuala Lumpur','Une école française ouvre à Kuala Lumpur')},
   {year:'1973', title:L('Death of Henri Fauconnier','Décès d’Henri Fauconnier')},
   {year:'2027', title:L('The campus that bears his name enters the Eurocampus era','Le campus qui porte son nom entre dans l’ère Eurocampus'), now:true}]}
 ]},
 '1-4':{prepend:[
  {t:'timeline', items:[
   {year:'1962', title:L('A small French school opens to serve a handful of French families','Une petite école française ouvre pour quelques familles françaises')},
   {year:L('60+ years','60 ans et plus'), title:L('A permanent fixture of the city’s educational landscape','Une présence durable dans le paysage éducatif de la ville')},
   {year:'2027', title:L('The Eurocampus era: French, German and English traditions on one campus','L’ère Eurocampus : traditions française, allemande et anglaise sur un même campus'), now:true}]}
 ]},
 '1-7':{blocks:[
  {t:'quad', center:L('One culture','Une culture'), items:[
   {num:'1', icon:R+'p012_1.png', title:L('Excellence','L’excellence'), text:L('Nurture and develop every form of excellence: in our students, our staff, our infrastructure and our services.','Entretenir et développer toutes les formes d’excellence. Des élèves, des personnels, des infrastructures et des services.'), tags:'RIGUEUR · EXIGENCE · RAYONNEMENT'},
   {num:'2', icon:R+'p012_2.png', title:L('International Mindset','L’esprit international'), text:L('Offer our students an international experience and international perspectives.','Offrir à nos élèves une expérience et des perspectives internationales.'), tags:'OUVERTURE · CURIOSITÉ · DIALOGUE'},
   {num:'3', icon:R+'p012_3.png', title:L('Sharing','Le partage'), text:L('Bring French culture to life and share it, bringing people together around common values.','Faire vivre et partager la culture française, rassembler autour de valeurs communes.'), tags:'TRANSMISSION · BIENVEILLANCE · COMMUNAUTÉ'},
   {num:'4', icon:R+'p012_4.png', title:L('Openness','L’ouverture'), text:L('Respect other cultures and open ourselves to them.','Respecter et s’ouvrir aux autres cultures.'), tags:'RESPECT · INCLUSION'}]}
 ]},
 '1-10':{blocks:[
  {t:'statement', size:'m', label:L('Our positioning','Notre positionnement'), text:L('FSKL is a French school open to families of all nationalities seeking academic excellence in an international environment.','FSKL est une école française ouverte aux familles de toutes nationalités qui recherchent l’excellence académique dans un environnement international.')},
  {t:'h', text:L('USP','Singularité')},
  {t:'list', style:'num', items:[
   {img:R+'p015_1.jpg', text:L('French academic excellence, guaranteed by AEFE, visible in pedagogy and results.','L’excellence académique française, garantie par l’AEFE, visible dans la pédagogie et les résultats.')},
   {img:R+'p015_2.png', text:L('An international, multicultural community life, present since 1962.','Une vie de communauté internationale et multiculturelle, présente depuis 1962.')},
   {img:R+'p015_3.png', text:L('The Eurocampus tricultural framework. FSKL’s particular contribution to the KL market.','Le cadre triculturel de l’Eurocampus. La contribution propre de FSKL au marché de Kuala Lumpur.')}]}
 ]},
 '1-12':{blocks:[
  {w:[5,7], cols:[[
   {t:'lead', text:L('We are __calm__, __confident__ and __warm__. Warm in the way a serious teacher is: __present__, __attentive__, __demanding__, and on the child’s side.','Nous sommes __calmes__, __confiants__ et __chaleureux__. Chaleureux à la manière d’un enseignant sérieux : __présent__, __attentif__, __exigeant__, et du côté de l’enfant.')}
  ],[
   {t:'venn', legend:true, center:L('Calm & confident','Calmes et sûrs'), items:[
    {title:L('Cultivation','Culture'), text:L('Slow growth, deep roots, patience as a value. (Hevea metaphor.)','Croissance lente, racines profondes, patience comme valeur. (Métaphore de l’hévéa.)')},
    {title:L('Clarity','Clarté'), text:L('The absence of noise. A clean campus, a clean diploma, a clean conversation.','L’absence de bruit. Un campus clair, un diplôme clair, un échange clair.')},
    {title:L('Continuity','Continuité'), text:L('A sense that this institution has existed before us and will exist after us. (Est. 1962 is a fact, not a sticker.)','Le sentiment que l’institution existait avant nous et existera après nous. (Établi en 1962 est un fait, non un autocollant.)')}]}
  ]]}
 ]},
 '1-17':{blocks:[
  {w:[4,8], cols:[[
   {t:'cards', cols:1, items:[{dur:20, label:L('6 sec','6 s'), title:L('Parent in passing','Parent croisé rapidement'), quote:true, text:L('“We are the French school that became a Eurocampus, French BAC, German neighbour, and English cert on one site.”','« Nous sommes l’école française devenue Eurocampus : baccalauréat français, voisin allemand et certification anglaise sur un même site. »')}]}
  ],[
   {t:'cards', cols:1, items:[{dur:100, label:L('30 sec','30 s'), title:L('Parent at open day','Parent lors d’une journée portes ouvertes'), quote:true, text:L('“We are the French School in Kuala Lumpur, AEFE-accredited, here since 1962. What’s specific to us is the Eurocampus: French, German, and English education integrated into shared school life, on one campus.\n\nChildren grow up genuinely multilingual and multicultural. Our graduates go on to universities in France, the UK, and beyond.\n\nThe campus is named for Henri Fauconnier, the French planter and Goncourt-winning author who first connected France and Malaysia.”','« Nous sommes la French School de Kuala Lumpur, homologuée AEFE, présente ici depuis 1962. Notre spécificité, c’est l’Eurocampus : les éducations française, allemande et anglaise intégrées dans une vie scolaire partagée, sur un même campus.\n\nLes enfants grandissent dans un environnement réellement multilingue et multiculturel. Nos diplômés poursuivent leurs études dans des universités en France, au Royaume-Uni et ailleurs.\n\nLe campus porte le nom d’Henri Fauconnier, planteur français et écrivain prix Goncourt, qui a relié la France et la Malaisie. »')}]}
  ]]}
 ]},
 '1-19':{blocks:[
  {t:'funnel', items:[
   {title:L('1. Core','1. Cœur'), text:L('A demanding French education in Kuala Lumpur: l’excellence française, ailleurs.','Une éducation française exigeante à Kuala Lumpur : l’excellence française, ailleurs.'), lead:L('Always present, often implicit.','Toujours présent, souvent implicite.')},
   {title:L('2. Differentiator','2. Différence'), text:L('The Eurocampus: French, German, and English educational traditions in shared school life.','L’Eurocampus : traditions éducatives française, allemande et anglaise dans une vie scolaire partagée.'), lead:L('Leads in admissions, leadership communication, parent first-contact.','Premier plan pour les admissions, la communication de direction et les premiers contacts avec les parents.')},
   {title:L('3. Proof','3. Preuve'), text:L('Founded 1962. AEFE-accredited. Graduates accepted to leading universities in France, the UK, and beyond.','Fondée en 1962. Homologuée AEFE. Diplômés admis dans de grandes universités en France, au Royaume-Uni et ailleurs.'), lead:L('Leads when credibility is the question.','Premier plan lorsque la crédibilité est l’enjeu.')},
   {title:L('4. Emotion','4. Émotion'), text:L('A school where children are formed and where they belong.','Une école où les enfants se construisent et trouvent leur place.'), lead:L('Leads in storytelling, social media, parent testimonial content.','Premier plan pour les récits, les réseaux sociaux et les témoignages de parents.')},
   {title:L('5. Community','5. Communauté'), text:L('A multicultural community of families committed to long-form education.','Une communauté multiculturelle de familles engagées dans une éducation au long cours.'), lead:L('Leads in community-building, alumni, retention.','Premier plan pour la vie de communauté, les anciens élèves et la fidélisation.')}]}
 ]},
 '1-20':{blocks:[
  {t:'poles', items:[
   {l:L('French primacy','Primauté française'), r:L('Tricultural equality','Égalité triculturelle'), text:L('French primacy is institutional (name, legal status, AEFE). Tricultural equality is operational and visual. Both appear, in that order.','La primauté française est institutionnelle (nom, statut juridique, AEFE). L’égalité triculturelle est opérationnelle et visuelle. Les deux apparaissent, dans cet ordre.')},
   {l:L('Tradition','Tradition'), r:L('Contemporaneity','Contemporanéité'), text:L('We are traditional in pedagogy and contemporary in execution. The brand looks 2026; the school feels 1962.','Nous sommes traditionnels dans la pédagogie et contemporains dans l’exécution. La marque regarde 2026 ; l’école porte 1962.')},
   {l:L('Institutional gravity','Gravité institutionnelle'), r:L('Child warmth','Chaleur envers l’enfant'), text:L('The brand surface is institutional. The brand interior, what happens in classrooms, is warm. We do not invert this. A “fun” institutional surface erodes trust.','La surface de la marque est institutionnelle. Son intérieur, ce qui se passe dans les classes, est chaleureux. Nous n’inversons pas cet ordre. Une surface institutionnelle trop « amusante » affaiblit la confiance.')},
   {l:L('AEFE compliance','Conformité AEFE'), r:L('Brand distinctiveness','Singularité de marque'), text:L('AEFE has its own visual identity (its logo, its statements). We display it where required. It never overrides ours. We are a member of the network; we are not the network.','L’AEFE possède sa propre identité visuelle (logo, messages). Nous l’affichons lorsque c’est requis. Elle ne prend jamais le pas sur la nôtre. Nous sommes membre du réseau ; nous ne sommes pas le réseau.')}]}
 ]},
 '1-21':{blocks:[
  {t:'orbit', coreLabel:L('Primary Audiences','Publics principaux'), satLabel:L('Secondary Audiences','Publics secondaires'),
   core:[
    {title:L('Prospective families','Familles candidates'), text:L('French expatriates, international-professional and mixed-nationality families.','Expatriés français, familles internationales, professionnelles et binationales.')},
    {title:L('Current families','Familles actuelles'), text:L('The community that lives the brand daily, retention and advocacy.','La communauté qui vit la marque au quotidien : fidélisation et recommandation.')},
    {title:L('Students','Élèves'), text:L('From maternelle to terminale, the people the school forms.','De la maternelle à la terminale, les personnes que l’école forme.')}],
   sats:[
    {title:L('Staff & teachers','Personnel & enseignants'), text:L('Daily producers of the operational layer.','Producteurs quotidiens du niveau opérationnel.')},
    {title:L('Alumni','Anciens élèves'), text:L('Student and Staff. A multi-decade relationship.','Élèves et personnel. Une relation sur plusieurs décennies.')},
    {title:L('Agencies & vendors','Agences & prestataires'), text:L('External executors of the brand.','Exécutants externes de la marque.')},
    {title:L('AEFE & partners','AEFE & partenaires'), text:L('The accreditation & institutional network.','Le réseau d’homologation et les partenaires institutionnels.')}]}
 ]},
 '3-0':{blocks:[
  {t:'timeline', imgH:96, items:[
   {year:L('1960s–1980s','1960–1980'), img:R+'p027_3.jpg', title:L('Circular seal','Sceau circulaire'), text:L('Institutional, embassy-style, early expatriate school','Institutionnel, proche des codes d’ambassade, école expatriée des débuts')},
   {year:L('1980s–2000s','1980–2000'), img:R+'p027_4.jpg', title:L('Watercolor hibiscus','Hibiscus aquarellé'), text:L('Strong local identity, informal, community-driven','Identité locale forte, informelle, portée par la communauté')},
   {year:'2005–2010', img:R+'p027_5.jpg', title:L('First “FSKL” + kite','Premier « FSKL » + cerf-volant'), text:L('Matches new campus move','Correspond au déménagement vers le nouveau campus')},
   {year:'2010–2026', img:R+'p027_1.png', title:L('Refined FSKL (Henri Fauconnier) + HEVEA','FSKL affiné (Henri Fauconnier) + HEVEA'), text:L('Modern system, expansion to primary','Système moderne, extension au primaire')},
   {year:'2027 →', img:'assets/logo/land.png', title:L('Eurocampus + IB Programme','Eurocampus + programme IB'), text:L('Cohesive, modular system','Système cohérent et modulaire'), now:true}]}
 ]},
 '3-2':{blocks:[
  {t:'callouts', img:'assets/logo/fav.png', left:[
   {icon:'assets/logo/coq-navy.png', title:L('The Coq Gaulois','Le coq gaulois'), text:L('First read is the historical emblem of France since the Renaissance. It signals national heritage without being a flag: more refined, more pedagogically appropriate. A second symbolic meaning is of __resilience__.','La première lecture renvoie à l’emblème historique de la France depuis la Renaissance. Il signale l’héritage national sans être un drapeau : plus raffiné, plus juste pour une institution éducative. Une seconde signification symbolique est celle de la __résilience__.')},
   {icon:'assets/logo/hevea-navy.png', title:L('The Hevea','L’hévéa'), text:L('The rubber tree that built the human relationship between France and Malaysia, and the tree most associated with Henri Fauconnier. A second reading evokes a laurel wreath, a symbol of academic achievement. A third reading evokes growth and development.','L’arbre à caoutchouc qui a construit la relation humaine entre la France et la Malaisie, et l’arbre le plus associé à Henri Fauconnier. Une seconde lecture évoque la couronne de laurier, symbole de réussite académique. Une troisième lecture évoque la croissance et le développement.')}],
   right:[
   {icon:'assets/logo/fav.png', title:L('The Escutcheon','L’écusson'), text:L('Its rounded base signals European-continental, not Anglo-Saxon, heraldic lineage. Academic dignity without monarchic association. It frames the two symbols.','Sa base arrondie signale une filiation héraldique européenne continentale, et non anglo-saxonne. Une dignité académique sans association monarchique. Il encadre les deux symboles.')},
   {icon:R+'p029_5.png', title:L('The Signature Shades','Les ombres de signature'), text:L('The tail acts as an echo of the very graphic element of the legacy logo: the shades/flags feature in the recess area of both campuses.','La queue fait écho à un élément très graphique du logo historique : les ombres/drapeaux présents dans les zones de retrait des deux campus.')}]}
 ]},
 '3-3':{blocks:[
  {t:'callouts', img:'assets/logo/wordmark.png', wide:true, left:[
   {title:L('Set in Montserrat Alternates','Composée en Montserrat Alternates'), text:L('A geometric sans with subtly softened terminals. Used for the wordmark only, never as a brand typeface.','Une sans-serif géométrique aux terminaisons légèrement adoucies. Utilisée uniquement pour la marque verbale, jamais comme police de marque.')},
   {title:L('Geometric sans-serif','Sans-serif géométrique'), text:L('The vocabulary of European cultural institutions, not British boarding schools.','Le vocabulaire des institutions culturelles européennes, non celui des pensionnats britanniques.')},
   {title:L('Slight compression','Compression légère'), text:L('Gives the wordmark institutional density.','Donne à la marque verbale une densité institutionnelle.')}],
   right:[
   {title:L('Softened terminals','Terminaisons adoucies'), text:L('Humanise the letterforms, warmth without losing seriousness.','Humanisent les formes de lettres : de la chaleur sans perdre le sérieux.')},
   {title:L('The four-letter monogram','Le monogramme de quatre lettres'), text:L('Is itself strategy, pronounceable for international audiences.','Est déjà une stratégie : prononçable par les publics internationaux.')}]}
 ]},
 '3-9':{blocks:[
  {t:'decision', q:L('Where will the logo live?','Où le logo sera-t-il exposé ?'), branches:[
   {label:L('Indoors · screens & print','Intérieur · écrans & imprimés'), imgs:['assets/logo/land.png'], title:L('Full Colour','Couleur'), text:L('Website & social media · Prospectus & brochures · Reception areas · Event graphics','Site web & réseaux sociaux · Prospectus & brochures · Espaces d’accueil · Graphismes d’événement')},
   {label:L('Outdoors · indirect UV','Extérieur · UV indirects'), imgs:['assets/logo/land-black.png'], title:L('Dark Blue / Black','Bleu foncé / noir'), text:L('Wayfinding signage · Vehicle livery · Sports banners · Outdoor graphics','Signalétique d’orientation · Marquage véhicules · Bannières sportives · Graphismes extérieurs')},
   {label:L('Outdoors · strong sun','Extérieur · fort soleil'), imgs:['assets/logo/emblem-black.jpg'], title:L('Raw Material','Matériau brut'), text:L('Building signage · Entrance monuments · Foundation plaques · Donor walls & plaques','Signalétique bâtiment · Monuments d’entrée · Plaques de fondation · Murs et plaques donateurs')}]},
  {w:[7,5], cols:[[
   {t:'lead', size:'s', text:L('The strong sun of Malaysia affect printed colour. A desaturated logotype appears quickly dated and irrelevant. We want to avoid this decay and damaging perception. The rule is if __this is printed and will stay under the sun, go for raw material (metal, wood, stone), black print or dark blue.__','Le fort soleil de Malaisie altère les couleurs imprimées. Un logotype désaturé paraît vite daté et peu pertinent. Nous voulons éviter cette dégradation et la perception qu’elle entraîne. La règle est simple : __si le support est imprimé et reste au soleil, privilégier le matériau brut (métal, bois, pierre), l’impression noire ou le bleu foncé.__')}
  ],[
   {t:'images', cols:1, items:[{src:R+'p036_1.png', fit:'contain', h:220, cap:L('Sun-faded print: to avoid','Impression délavée au soleil : à éviter')}]}
  ]]}
 ]},
 '7-1':{append:[
  {t:'h', text:L('Aspect ratios','Ratios')},
  {t:'ratios', items:[
   {r:'3:2', a:3, b:2, use:L('Editorial','Éditorial')},
   {r:'4:5', a:4, b:5, use:L('Instagram feed','Fil Instagram')},
   {r:'9:16', a:9, b:16, use:L('Stories and Reels','Stories et Reels')},
   {r:'16:9', a:16, b:9, use:L('Video and YouTube','Vidéo et YouTube')},
   {r:'1:1', a:1, b:1, use:L('Grid composition and certain print uses','Compositions en grille et certains usages imprimés')}]}
 ]},
 '7-5':{append:[
  {t:'gantt', title:L('The grade at a glance','L’étalonnage en un coup d’œil'), min:-30, max:30, zero:0, ticks:[{v:-30,l:'-30'},{v:-20,l:'-20'},{v:-10,l:'-10'},{v:0,l:'0'},{v:10,l:'+10'},{v:20,l:'+20'},{v:30,l:'+30'}], rows:[
   {label:L('Exposure','Exposition'), from:5, to:10, note:'+5 / +10', bg:'#002654'},
   {label:L('Contrast','Contraste'), from:10, to:25, note:'+10 / +25', bg:'#002654'},
   {label:L('Highlights','Hautes lumières'), from:-10, to:0, note:'-10 %', bg:'#CC0000'},
   {label:L('Texture','Texture'), from:0, to:10, note:'+10 %', bg:'#002654'},
   {label:L('Clarity','Clarté'), from:-10, to:0, note:'-10 %', bg:'#CC0000'},
   {label:L('Saturation','Saturation'), from:-5, to:-3, note:'-3 / -5 %', bg:'#CC0000'},
   {label:L('Vibrance','Vibrance'), from:5, to:10, note:'+5 / +10 %', bg:'#002654'}]}
 ]},
 '7-8':{append:[
  {t:'gantt', title:L('When to shoot the campus','Quand photographier le campus'), min:6, max:19, ticks:[{v:6,l:'06:00'},{v:8,l:'08:00'},{v:10,l:'10:00'},{v:12,l:'12:00'},{v:14,l:'14:00'},{v:16,l:'16:00'},{v:19,l:'19:00'}], rows:[
   {label:L('Before assembly','Avant le rassemblement'), from:7, to:7.75, note:'07:00–07:45', bg:'#FFD100', fg:'#111111'},
   {label:L('After dismissal','Après la sortie'), from:16, to:17.5, note:'16:00–17:30', bg:'#FFD100', fg:'#111111'}]}
 ]},
 '7-12':{append:[
  {t:'gantt', title:L('Title card timing (seconds)','Minutage du carton-titre (secondes)'), min:0, max:3.2, ticks:[{v:0,l:'0 s'},{v:0.4,l:'0.4'},{v:2.8,l:'2.8'},{v:3.2,l:'3.2 s'}], rows:[
   {label:L('Fade in','Fondu entrant'), from:0, to:0.4, note:'400 ms', bg:'#4F4A47'},
   {label:L('Hold','Maintien'), from:0.4, to:2.8, note:'2.4 s', bg:'#002654'},
   {label:L('Fade out','Fondu sortant'), from:2.8, to:3.2, note:'400 ms', bg:'#4F4A47'}]}
 ]},
 '8-0':{blocks:[
  {t:'social', title:L('Platforms','Plateformes'), items:[{name:'Instagram',icon:'instagram'},{name:'LinkedIn',icon:'linkedin'},{name:'YouTube',icon:'youtube'},{name:'Facebook',icon:'facebook'},{name:'WhatsApp',icon:'whatsapp'},{name:'TikTok',icon:'tiktok'}], note:L('Reference glyphs in French Deep Blue. Use each platform’s official artwork when linking out.','Pictogrammes de référence en bleu profond français. Utilisez le visuel officiel de chaque plateforme pour les liens sortants.')},
  {t:'table', head:[L('Platform','Plateforme'), L('Function','Fonction'), L('Cadence','Cadence')], rows:[
   ['Instagram (@lfkl_hevea)', L('Brand atmosphere, school life, parent community','Atmosphère de marque, vie de l’école, communauté des parents'), L('3 posts/week + 5 stories/week + 1 Reel/week.','3 publications/semaine + 5 stories/semaine + 1 Reel/semaine.')],
   ['LinkedIn (Lycée Français de Kuala Lumpur LFKL)', L('Institutional credibility, employer brand, alumni network.','Crédibilité institutionnelle, marque employeur, réseau des anciens.'), L('2 posts/week.','2 publications/semaine.')],
   ['YouTube (LFKL)', L('Long-form content. The ‘show, don’t tell’ of the school.','Contenu long. Montrer l’école plutôt que l’expliquer.'), L('One major film per quarter. Short documentary pieces monthly. 16:9 primary; 9:16 Shorts secondary.','Un film majeur par trimestre. Courts formats documentaires chaque mois. 16:9 principal ; Shorts 9:16 secondaires.')]]},
  {t:'donuts', charts:[
   {title:'Instagram (@lfkl_hevea)', center:L('Content mix','Répartition'), items:[
    {name:L('School life documentary','Vie scolaire documentaire'), pct:50, bg:'#002654'},
    {name:L('Editorial / institutional','Éditorial / institutionnel'), pct:25, bg:'#5B7397'},
    {name:L('Community voices','Voix de la communauté'), pct:15, bg:'#FFD100'},
    {name:L('Promotional (open days, deadlines)','Promotionnel (portes ouvertes, échéances)'), pct:10, bg:'#CC0000'}]},
   {title:'LinkedIn', center:L('Content mix','Répartition'), items:[
    {name:L('Institutional news','Actualités institutionnelles'), pct:40, bg:'#002654'},
    {name:L('Faculty thought leadership','Prises de parole des enseignants'), pct:25, bg:'#5B7397'},
    {name:L('Alumni stories','Récits d’anciens'), pct:20, bg:'#FFD100'},
    {name:L('Recruitment','Recrutement'), pct:15, bg:'#CC0000'}]}]},
  {t:'cards', cols:3, items:[
   {label:L('Not maintained','Non animé'), title:'TikTok', text:L('Not currently maintained. The platform’s tonal range is misaligned with the brand. Re-evaluate annually.','Non animé actuellement. Le ton de la plateforme est peu aligné avec la marque. Réévaluation annuelle.')},
   {label:L('Parents only','Parents uniquement'), title:'Facebook', text:L('Maintained for the parent community only. Closed group, not a public page. New parents receive the link in the welcome packet.','Maintenu uniquement pour la communauté des parents. Groupe fermé, pas page publique. Les nouveaux parents reçoivent le lien dans le dossier d’accueil.')},
   {label:L('Transactional only','Transactionnel uniquement'), title:'WhatsApp', text:L('Used for transactional communication only. Admissions and emergency notifications. Not a marketing channel.','Utilisé seulement pour les communications transactionnelles. Admissions et notifications d’urgence. Pas un canal marketing.')}]}
 ]},
 '10-2':{append:[
  {t:'h', text:L('Bilingualism rule at a glance','La règle de bilinguisme en un coup d’œil')},
  {t:'matrix', head:['FR','EN','DE'], l1:L('Primary','Principal'), l2:L('Secondary','Secondaire'), l3:L('Trilingual','Trilingue'), rows:[
   {label:L('French Section signs','Section française'), cells:[1,2,0]},
   {label:L('German Section signs','Section allemande'), cells:[0,2,1]},
   {label:L('English Section signs','Section anglaise'), cells:[2,1,0]},
   {label:L('Shared facilities (cafeteria, library, gym, auditorium)','Espaces partagés (cafétéria, bibliothèque, gymnase, auditorium)'), cells:[3,3,3]}]}
 ]},
 '10-4':{blocks:[
  {w:[5,7], cols:[[
   {t:'elevation', plateW:200, plateH:150, height:1450, label:L('Eye-level for adults; visible to children','Hauteur des yeux pour les adultes ; visible par les enfants'), floor:L('Floor','Sol')},
   {t:'list', style:'defs', items:[
    {title:L('Plate','Plaque'), text:L('Engraved acrylic, 200 × 150 mm, mounted at 1450 mm above floor (eye-level for adults; visible to children for orientation).','Acrylique gravé, 200 × 150 mm, posé à 1450 mm du sol (hauteur des yeux pour les adultes ; visible par les enfants pour l’orientation).')},
    {title:L('Status card','Carte de statut'), text:L('A small interchangeable card pocket below holds: “In class” / “On break” / “Off-site” Montserrat font, colour-coded.','Une petite pochette interchangeable en dessous indique : « En classe » / « En pause » / « Hors site » en Montserrat, avec code couleur.')}]}
  ],[
   {t:'images', cols:2, items:[{src:R+'p097_1.jpg', h:420},{src:R+'p097_2.jpg', h:420}]}
  ]]}
 ]},
 '10-8':{append:[
  {t:'h', text:L('A physical rite of passage','Un rite de passage physique')},
  {t:'flow', items:[{title:L('Collège','Collège'), text:L('Camus / Goethe buildings','Bâtiments Camus / Goethe')},{title:L('Lycée','Lycée'), text:L('Conrad / Curie / Le Clézio buildings','Bâtiments Conrad / Curie / Le Clézio')}]}
 ]},
 '10-14':{blocks:[
  {t:'journey', items:[
   {h:L('Before joining','Avant l’inscription')},
   {n:'1', title:L('First enquiry response time','Délai de réponse première demande'), text:L('**Under 24 hours, in the parent’s language.**','**Moins de 24 heures, dans la langue du parent.**')},
   {n:'2', title:L('Open day','Portes ouvertes'), text:L('Begins on time. Ends on time. The Proviseur speaks for 12 minutes maximum, then answers questions. No PowerPoint over 12 slides.','Commence à l’heure. Termine à l’heure. Le Proviseur parle 12 minutes maximum, puis répond aux questions. Pas de PowerPoint de plus de 12 slides.')},
   {n:'3', title:L('Campus tours','Visites du campus'), text:L('Led by current students (lycée volunteers) accompanied by a staff member. Real classrooms visited. No theatrical “show-rooms.”','Conduites par des élèves actuels (lycéens volontaires) accompagnés d’un membre du personnel. Vraies classes visitées. Pas de « show-rooms » théâtralisés.')},
   {n:'4', title:L('Enrolment documents','Dossiers d’inscription'), text:L('Designed, bilingual, on Vellum paper. The enrolment forms themselves are part of the brand.','Conçus, bilingues, sur papier Vélin. Les formulaires d’inscription font partie de la marque.')},
   {n:'5', title:L('Welcome emails','E-mails de bienvenue'), text:L('A 4-email onboarding sequence over 14 days.','Séquence d’intégration de 4 e-mails sur 14 jours.')},
   {h:L('Once enrolled','Une fois inscrits')},
   {title:L('Newsletters','Newsletters'), text:L('La Lettre monthly, designed, bilingual. Never a wall of text.','La Lettre mensuelle, conçue, bilingue. Jamais un mur de texte.')},
   {title:L('Parent portal','Portail parents'), text:L('Co-branded with the school information system (Pronote or equivalent); FSKL colours and typography applied via the system’s customisation.','Co-marqué avec le système d’information scolaire (Pronote ou équivalent) ; couleurs et typographie FSKL appliquées via la personnalisation du système.')},
   {title:L('School app','Application école'), text:L('Custom-developed in time; in the interim, the school relies on Pronote’s app + WhatsApp Business channels for transactional communication.','Développée sur mesure à terme ; dans l’intervalle, l’école s’appuie sur l’application Pronote + les canaux WhatsApp Business pour les communications transactionnelles.')},
   {title:L('Parent-teacher meetings','Réunions parents-professeurs'), text:L('Scheduled in 12-minute slots. A standard form used by the teacher to prepare. A take-home note for the parent (printed on Vellum, signed).','Créneaux de 12 minutes. Formulaire standard utilisé par l’enseignant pour préparer. Note remise au parent (imprimée sur Vélin, signée).')},
   {title:L('Event invitations','Invitations événements'), text:L('Printed invitations on Vellum card stock for major events (graduations, gala); designed digital invitations for all others.','Invitations imprimées sur carte Vélin pour les grands événements (remises de diplômes, gala) ; invitations numériques conçues pour les autres.')},
   {h:L('Reference publications','Publications de référence')},
   {title:L('Annual report','Rapport annuel'), text:L('A 40-page bound document mailed to current families and major donors each November.','Document relié de 40 pages envoyé chaque novembre aux familles actuelles et grands donateurs.')},
   {title:L('School prospectus','Prospectus de l’école'), text:L('A 60-page hardback book, issued every two years, that is the master physical brand asset.','Livre relié cartonné de 60 pages, publié tous les deux ans, actif physique principal de la marque.')},
   {title:L('Admissions brochure','Brochure admissions'), text:L('A 24-page softcover booklet, refreshed annually, designed for the open-day take-away.','Livret souple de 24 pages, actualisé chaque année, conçu pour être emporté lors des portes ouvertes.')}]}
 ]},
 '10-15':{blocks:[
  {t:'gantt', min:600, max:810, ticks:[{v:600,l:'10:00'},{v:660,l:'11:00'},{v:720,l:'12:00'},{v:780,l:'13:00'},{v:810,l:'13:30'}], rows:[
   {label:L('Welcome','Accueil'), from:600, to:615, note:'10:00', bg:'#4F4A47'},
   {label:L('Proviseur talk','Intervention du Proviseur'), from:615, to:630, note:'10:15', bg:'#002654'},
   {label:L('Section heads (3 × 6 minutes)','Chefs de section (3 × 6 minutes)'), from:630, to:648, note:'10:30', bg:'#002654'},
   {label:L('Campus tour','Visite du campus'), from:660, to:720, note:'11:00', bg:'#CC0000'},
   {label:L('Parent panel','Panel parents'), from:720, to:750, note:'12:00', bg:'#002654'},
   {label:L('Light lunch with current parents','Déjeuner léger avec parents actuels'), from:750, to:810, note:'12:30', bg:'#FFD100', fg:'#111111'},
   {label:L('Close','Clôture'), from:810, to:810, note:'13:30', bg:'#111111'}]},
  {t:'list', style:'defs', items:[
   {title:L('Staffing','Équipe'), text:L('Every senior leader present. Every section head present. A roster of student ambassadors (15–25 students depending on expected attendance).','Tous les cadres présents. Tous les chefs de section présents. Une équipe d’élèves ambassadeurs (15–25 élèves selon l’affluence attendue).')},
   {title:L('Materials','Supports'), text:L('Welcome packet (admissions brochure + programme flyer + fees sheet + visit-card); a personal name badge; a campus map (designed, bilingual).','Dossier d’accueil (brochure admissions + flyer programme + grille tarifaire + carte de visite) ; badge nominatif personnel ; plan du campus (conçu, bilingue).')},
   {title:L('Catering','Traiteur'), text:L('A French-Malaysian tea: kuih, macarons, fresh fruit, tea and coffee. Plated, on Vellum-toned linen, not a buffet of muffins.','Un thé franco-malaisien : kuih, macarons, fruits frais, thé et café. Présentation à l’assiette, sur linge ton Vélin, pas un buffet de muffins.')},
   {title:L('Atmosphere','Atmosphère'), text:L('No music. No floor stickers. No balloon arches. The brand earns trust through restraint.','Pas de musique. Pas de stickers au sol. Pas d’arche de ballons. La marque gagne la confiance par la retenue.')}]}
 ]}
};
window.FSKL_PATCH.__add={p5:[
 {id:'5-9', after:'5-8', kicker:L('6.8 · Font downloads','6.8 · Téléchargement des polices'), title:L('Get the typefaces','Obtenir les polices'), sub:L('All brand typefaces are free to download and install. Install them before opening any brand file.','Toutes les polices de la marque se téléchargent et s’installent gratuitement. Installez-les avant d’ouvrir un fichier de marque.'), blocks:[
  {t:'fontlinks', items:[
   {name:'Baskerville', stack:'Baskerville, "Libre Baskerville", Georgia, serif', role:L('Headings · Levels 1 & 2','Titres · Niveaux 1 & 2'), note:L('Installed with macOS and Microsoft Office. Libre Baskerville is the free web and fallback version.','Installée avec macOS et Microsoft Office. Libre Baskerville est la version libre pour le web et le repli.'), links:[{label:L('Libre Baskerville','Libre Baskerville'), url:'https://fonts.google.com/specimen/Libre+Baskerville'}]},
   {name:'Montserrat', stack:'Montserrat, Arial, sans-serif', role:L('Body and interface · Level 1','Texte et interface · Niveau 1'), note:L('Free on Google Fonts. Download the full family, including all weights.','Gratuite sur Google Fonts. Télécharger la famille complète, tous les graisses incluses.'), links:[{label:L('Download Montserrat','Télécharger Montserrat'), url:'https://fonts.google.com/specimen/Montserrat'}]},
   {name:'Arial', stack:'Arial, Helvetica, sans-serif', role:L('Body and documents · Level 2','Texte et documents · Niveau 2'), note:L('Preinstalled on Windows and macOS and available in Google Workspace and Office. Nothing to install.','Préinstallée sur Windows et macOS, disponible dans Google Workspace et Office. Rien à installer.'), links:[{label:L('Arial on Microsoft Typography','Arial sur Microsoft Typography'), url:'https://learn.microsoft.com/en-us/typography/font-list/arial'}]}
  ]}
 ]}
],p6:[
 {id:'6-4', kicker:L('7.4 · Pictogram library','7.4 · Bibliothèque de pictogrammes'), title:L('Lucide, our pictogram library','Lucide, notre bibliothèque de pictogrammes'), blocks:[
  {w:[6,6], cols:[[
   {t:'lead', text:L('Lucide is the best choice for FSKL.','Lucide est le meilleur choix pour FSKL.')},
   {t:'p', text:L('Lucide has a much stronger consistency of style: the icons follow a strict grid, constant weights, and a clean, minimalist design philosophy. This is exactly the register established for FSKL: rational, clean, without unnecessary ornament. Lucide icons sit naturally with careful typography and a restrained palette.','Lucide a une cohérence de style beaucoup plus forte — les icônes suivent une grille stricte, des poids constants, et une philosophie de design minimaliste épurée. C’est exactement le registre que vous avez établi pour FSKL : rationnel, épuré, sans ornement inutile. Les icônes de Lucide s’intègrent naturellement à une typographie soignée et une palette constrictive.')}
  ],[
   {t:'list', style:'defs', items:[
    {title:L('Grid','Grille'), text:L('24 × 24 px, as drawn by Lucide.','24 × 24 px, tel que dessiné par Lucide.')},
    {title:L('Stroke','Trait'), text:L('2 px, round caps and joins. Never filled.','2 px, extrémités et jonctions arrondies. Jamais rempli.')},
    {title:L('Colour','Couleur'), text:L('French Deep Blue or Near Black. White on navy.','Bleu profond français ou noir profond. Blanc sur bleu nuit.')},
    {title:L('One library only','Une seule bibliothèque'), text:L('Never mix Lucide with another icon set in the same document.','Ne jamais mélanger Lucide avec une autre famille d’icônes dans un même document.'), bad:true}]}
  ]]},
  {t:'icons', hint:L('Click an icon to copy its Lucide name.','Cliquez sur une icône pour copier son nom Lucide.'), names:['school','graduation-cap','book-open','library','pencil','palette','flask-conical','microscope','calculator','globe','languages','music','trophy','award','bus','utensils','calendar','clock','map-pin','phone','mail','users','backpack','bell','camera','clipboard-check','shield-check','heart-handshake','leaf','sun','accessibility','info']}
 ]},
 {id:'6-1b', after:'6-1', kicker:L('7.1 · The campus flags · Kite curves','7.1 · Les drapeaux du campus · Courbes des voiles'), title:L('Kite curves: masks and section dividers','Courbes des voiles : masques et séparateurs'), sub:L('The curves of the campus kites, applied as masks or section dividers. Two shapes, two flips, three heights, the full palette. Start from a preset or build your own.','Les courbes des voiles du campus, appliquées en masques ou en séparateurs. Deux formes, deux retournements, trois hauteurs, toute la palette. Partez d’un préréglage ou composez le vôtre.'), blocks:[
  {t:'curves', img:R+'p066_1.jpg',
   lbl:{presets:L('Presets','Préréglages'), shape:L('Shape','Forme'), rounded:L('Rounded','Arrondie'), scalloped:L('Scalloped','Festonnée'), flip:L('Flip','Retourner'), flipV:L('Vertical','Vertical'), flipH:L('Horizontal','Horizontal'), height:L('Height','Hauteur'), colour:L('Colour','Couleur'), use:L('Use','Usage'), divider:L('Section divider','Séparateur de section'), mask:L('Photo mask','Masque photo')},
   colors:[{name:L('French Deep Blue','Bleu profond français'),v:'#002654'},{name:L('Malaysian Red','Rouge malaisien'),v:'#CC0000'},{name:L('Near Black','Noir profond'),v:'#111111'},{name:L('Vellum','Vélin'),v:'#F9F1EC'},{name:L('White','Blanc'),v:'#FFFFFF'}],
   presets:[{n:'K1',s:0,v:1,h:0},{n:'K2',s:1,v:1,h:0},{n:'K3',s:0,v:0,h:0},{n:'K4',s:1,v:1,h:1},{n:'K5',s:1,v:0,h:0},{n:'K6',s:1,v:0,h:1}]},
  {t:'list', style:'check', items:[
   L('Heights S, M or L only. The curve supports the layout; it never dominates it.','Hauteurs S, M ou L uniquement. La courbe accompagne la mise en page ; elle ne la domine jamais.'),
   L('One curve per composition.','Une seule courbe par composition.'),
   L('Curves are never rotated, distorted or stacked.','Les courbes ne sont jamais pivotées, déformées ni superposées.'),
   L('The logo never sits on the curve edge; keep the clear space x.','Le logo ne se place jamais sur le bord de la courbe ; respecter l’espace libre x.')]}
 ]}
]};
window.FSKL_PATCH.__parts=[{id:'p13', num:'02', title:L('Downloads','Téléchargements'), intro:L('The official logo, font and icon files for teachers and administration. Choose a version, then download it. Always use these files, never a re-export or a screenshot.','Les fichiers officiels des logos, polices et icônes pour les enseignants et l’administration. Choisissez une version, puis téléchargez-la. Utilisez toujours ces fichiers, jamais une réexportation ni une capture d’écran.'), sections:[
 {id:'13-1', kicker:L('2.1 · Brand library','2.1 · Bibliothèque de marque'), title:L('Choose a file, then download it','Choisissez un fichier, puis téléchargez-le'), sub:L('White versions are shown on Bleu Nuit. Use them on dark grounds only.','Les versions blanches sont présentées sur Bleu Nuit. À utiliser uniquement sur fonds sombres.'), blocks:[
  {t:'downloads', lbl:{download:L('Download','Télécharger'), version:L('Version','Version')}, groups:[
  {title:L('Lockups','Assemblages'), items:[
   {name:L('L1 · Vertical','L1 · Vertical'), variants:[{label:L('Colour','Couleur'), file:'assets/logo/portrait.png'}, {label:L('Black','Noir'), file:'assets/logo/portrait-black.png'}, {label:L('White + colour','Blanc + couleur'), file:'assets/logo/portrait-negblue.png', bg:'#002654'}, {label:L('White','Blanc'), file:'assets/logo/portrait-neg.png', bg:'#002654'}]},
   {name:L('L2 · Horizontal','L2 · Horizontal'), variants:[{label:L('Colour','Couleur'), file:'assets/logo/land.png'}, {label:L('Black','Noir'), file:'assets/logo/land-black.png'}, {label:L('White + colour','Blanc + couleur'), file:'assets/logo/land-negblue.png', bg:'#002654'}, {label:L('White','Blanc'), file:'assets/logo/land-neg.png', bg:'#002654'}, {label:L('Long','Long'), file:'assets/logo/land-long.png'}, {label:L('Email','E-mail'), file:'assets/logo/land-email.png'}]},
   {name:L('L3 · Stacked, no shield','L3 · Empilé, sans écu'), variants:[{label:L('Colour','Couleur'), file:'assets/logo/types.png'}, {label:L('Black','Noir'), file:'assets/logo/types-black.png'}, {label:L('White + colour','Blanc + couleur'), file:'assets/logo/types-negblue.png', bg:'#002654'}, {label:L('White','Blanc'), file:'assets/logo/types-neg.png', bg:'#002654'}]},
   {name:L('L4 · Wordmark FSKL','L4 · Marque verbale FSKL'), variants:[{label:L('Colour','Couleur'), file:'assets/logo/wordmark.png'}, {label:L('Black','Noir'), file:'assets/logo/wordmark-black.png'}, {label:L('White + colour','Blanc + couleur'), file:'assets/logo/wordmark-negblue.png', bg:'#002654'}, {label:L('White','Blanc'), file:'assets/logo/wordmark-neg.png', bg:'#002654'}]},
   {name:L('L5 · Roundel','L5 · Médaillon'), variants:[{label:L('Colour','Couleur'), file:'assets/logo/emblem.png'}, {label:L('Black','Noir'), file:'assets/logo/emblem-black.png'}, {label:L('White + colour','Blanc + couleur'), file:'assets/logo/emblem-negblue.jpg', bg:'#002654'}, {label:L('White','Blanc'), file:'assets/logo/emblem-neg.jpg', bg:'#002654'}]},
   {name:L('L6 · Shield','L6 · Écu'), variants:[{label:L('Colour','Couleur'), file:'assets/logo/fav.png'}]}
  ]},
  {title:L('Partners','Partenaires'), items:[
   {name:L('FSKL + AEFE','FSKL + AEFE'), variants:[{label:L('Colour','Couleur'), file:'assets/logo/master-aefe-v2.png'}]},
   {name:L('FSKL + République française + AEFE','FSKL + République française + AEFE'), variants:[{label:L('Colour','Couleur'), file:'assets/logo/master-rf-aefe-v2.png'}]}
  ]},
  {title:L('Graphic signatures','Signatures graphiques'), items:[
   {name:L('Coq','Coq'), variants:[{label:L('Navy','Bleu nuit'), file:'assets/logo/coq-navy.png'}, {label:L('White','Blanc'), file:'assets/logo/coq-white.png', bg:'#002654'}, {label:L('Vellum','Vélin'), file:'assets/logo/coq-vellum.png', bg:'#002654'}, {label:L('Tint','Teinte'), file:'assets/logo/coq-tint.png'}]},
   {name:L('Hevea leaf','Feuille d’hévéa'), variants:[{label:L('Navy','Bleu nuit'), file:'assets/logo/hevea-navy.png'}, {label:L('White','Blanc'), file:'assets/logo/hevea-white.png', bg:'#002654'}, {label:L('Vellum','Vélin'), file:'assets/logo/hevea-vellum.png', bg:'#002654'}, {label:L('Tint','Teinte'), file:'assets/logo/hevea-tint.png'}]}
  ]},
  {title:L('Institutional logos','Logos institutionnels'), items:[
   {name:L('République française','République française'), variants:[{label:L('Colour','Couleur'), file:'assets/logo/rf-color.png', pdf:'assets/logo/rf-color.pdf'}, {label:L('Black','Noir'), file:'assets/logo/rf-black.png', pdf:'assets/logo/rf-black.pdf'}, {label:L('White','Blanc'), file:'assets/logo/rf-white.png', pdf:'assets/logo/rf-white.pdf', bg:'#002654'}]},
   {name:L('AEFE','AEFE'), variants:[{label:L('Colour','Couleur'), file:'assets/logo/aefe-color.png', pdf:'assets/logo/aefe-color.pdf'}, {label:L('Black','Noir'), file:'assets/logo/aefe-black.png', pdf:'assets/logo/aefe-black.pdf'}, {label:L('White','Blanc'), file:'assets/logo/aefe-white.png', pdf:'assets/logo/aefe-white.pdf', bg:'#002654'}]}
  ]},
  {title:L('Fonts','Polices'), items:[
   {name:'Montserrat', variants:[{label:'Regular', file:'assets/downloads/fonts/Montserrat_400Regular.ttf', raw:true, glyph:'Aa', fw:400, stack:'Montserrat, Arial, sans-serif'}, {label:'Italic', file:'assets/downloads/fonts/Montserrat_400Regular_Italic.ttf', raw:true, glyph:'Aa', fw:400, stack:'Montserrat, Arial, sans-serif'}, {label:'Medium', file:'assets/downloads/fonts/Montserrat_500Medium.ttf', raw:true, glyph:'Aa', fw:500, stack:'Montserrat, Arial, sans-serif'}, {label:'SemiBold', file:'assets/downloads/fonts/Montserrat_600SemiBold.ttf', raw:true, glyph:'Aa', fw:600, stack:'Montserrat, Arial, sans-serif'}, {label:'Bold', file:'assets/downloads/fonts/Montserrat_700Bold.ttf', raw:true, glyph:'Aa', fw:700, stack:'Montserrat, Arial, sans-serif'}, {label:'ExtraBold', file:'assets/downloads/fonts/Montserrat_800ExtraBold.ttf', raw:true, glyph:'Aa', fw:800, stack:'Montserrat, Arial, sans-serif'}, {label:L('Licence','Licence'), file:'assets/downloads/fonts/OFL-Montserrat.txt', raw:true, glyph:'Aa', fw:400, stack:'Montserrat, Arial, sans-serif'}]},
   {name:'Libre Baskerville', variants:[{label:'Regular', file:'assets/downloads/fonts/LibreBaskerville_400Regular.ttf', raw:true, glyph:'Aa', fw:400, stack:'\'Libre Baskerville\', Georgia, serif'}, {label:'Italic', file:'assets/downloads/fonts/LibreBaskerville_400Regular_Italic.ttf', raw:true, glyph:'Aa', fw:400, stack:'\'Libre Baskerville\', Georgia, serif'}, {label:'Bold', file:'assets/downloads/fonts/LibreBaskerville_700Bold.ttf', raw:true, glyph:'Aa', fw:700, stack:'\'Libre Baskerville\', Georgia, serif'}, {label:L('Licence','Licence'), file:'assets/downloads/fonts/OFL-LibreBaskerville.txt', raw:true, glyph:'Aa', fw:400, stack:'\'Libre Baskerville\', Georgia, serif'}]}
  ]},
  {title:L('Icons · Lucide','Icônes · Lucide'), items:[
   {name:'school', variants:[{label:'SVG', file:'assets/downloads/icons/school.svg', raw:true, preview:'assets/downloads/icons/school.svg'}]},
   {name:'graduation-cap', variants:[{label:'SVG', file:'assets/downloads/icons/graduation-cap.svg', raw:true, preview:'assets/downloads/icons/graduation-cap.svg'}]},
   {name:'book-open', variants:[{label:'SVG', file:'assets/downloads/icons/book-open.svg', raw:true, preview:'assets/downloads/icons/book-open.svg'}]},
   {name:'library', variants:[{label:'SVG', file:'assets/downloads/icons/library.svg', raw:true, preview:'assets/downloads/icons/library.svg'}]},
   {name:'pencil', variants:[{label:'SVG', file:'assets/downloads/icons/pencil.svg', raw:true, preview:'assets/downloads/icons/pencil.svg'}]},
   {name:'palette', variants:[{label:'SVG', file:'assets/downloads/icons/palette.svg', raw:true, preview:'assets/downloads/icons/palette.svg'}]},
   {name:'flask-conical', variants:[{label:'SVG', file:'assets/downloads/icons/flask-conical.svg', raw:true, preview:'assets/downloads/icons/flask-conical.svg'}]},
   {name:'microscope', variants:[{label:'SVG', file:'assets/downloads/icons/microscope.svg', raw:true, preview:'assets/downloads/icons/microscope.svg'}]},
   {name:'calculator', variants:[{label:'SVG', file:'assets/downloads/icons/calculator.svg', raw:true, preview:'assets/downloads/icons/calculator.svg'}]},
   {name:'globe', variants:[{label:'SVG', file:'assets/downloads/icons/globe.svg', raw:true, preview:'assets/downloads/icons/globe.svg'}]},
   {name:'languages', variants:[{label:'SVG', file:'assets/downloads/icons/languages.svg', raw:true, preview:'assets/downloads/icons/languages.svg'}]},
   {name:'music', variants:[{label:'SVG', file:'assets/downloads/icons/music.svg', raw:true, preview:'assets/downloads/icons/music.svg'}]},
   {name:'trophy', variants:[{label:'SVG', file:'assets/downloads/icons/trophy.svg', raw:true, preview:'assets/downloads/icons/trophy.svg'}]},
   {name:'award', variants:[{label:'SVG', file:'assets/downloads/icons/award.svg', raw:true, preview:'assets/downloads/icons/award.svg'}]},
   {name:'bus', variants:[{label:'SVG', file:'assets/downloads/icons/bus.svg', raw:true, preview:'assets/downloads/icons/bus.svg'}]},
   {name:'utensils', variants:[{label:'SVG', file:'assets/downloads/icons/utensils.svg', raw:true, preview:'assets/downloads/icons/utensils.svg'}]},
   {name:'calendar', variants:[{label:'SVG', file:'assets/downloads/icons/calendar.svg', raw:true, preview:'assets/downloads/icons/calendar.svg'}]},
   {name:'clock', variants:[{label:'SVG', file:'assets/downloads/icons/clock.svg', raw:true, preview:'assets/downloads/icons/clock.svg'}]},
   {name:'map-pin', variants:[{label:'SVG', file:'assets/downloads/icons/map-pin.svg', raw:true, preview:'assets/downloads/icons/map-pin.svg'}]},
   {name:'phone', variants:[{label:'SVG', file:'assets/downloads/icons/phone.svg', raw:true, preview:'assets/downloads/icons/phone.svg'}]},
   {name:'mail', variants:[{label:'SVG', file:'assets/downloads/icons/mail.svg', raw:true, preview:'assets/downloads/icons/mail.svg'}]},
   {name:'users', variants:[{label:'SVG', file:'assets/downloads/icons/users.svg', raw:true, preview:'assets/downloads/icons/users.svg'}]},
   {name:'backpack', variants:[{label:'SVG', file:'assets/downloads/icons/backpack.svg', raw:true, preview:'assets/downloads/icons/backpack.svg'}]},
   {name:'bell', variants:[{label:'SVG', file:'assets/downloads/icons/bell.svg', raw:true, preview:'assets/downloads/icons/bell.svg'}]},
   {name:'camera', variants:[{label:'SVG', file:'assets/downloads/icons/camera.svg', raw:true, preview:'assets/downloads/icons/camera.svg'}]},
   {name:'clipboard-check', variants:[{label:'SVG', file:'assets/downloads/icons/clipboard-check.svg', raw:true, preview:'assets/downloads/icons/clipboard-check.svg'}]},
   {name:'shield-check', variants:[{label:'SVG', file:'assets/downloads/icons/shield-check.svg', raw:true, preview:'assets/downloads/icons/shield-check.svg'}]},
   {name:'heart-handshake', variants:[{label:'SVG', file:'assets/downloads/icons/heart-handshake.svg', raw:true, preview:'assets/downloads/icons/heart-handshake.svg'}]},
   {name:'leaf', variants:[{label:'SVG', file:'assets/downloads/icons/leaf.svg', raw:true, preview:'assets/downloads/icons/leaf.svg'}]},
   {name:'sun', variants:[{label:'SVG', file:'assets/downloads/icons/sun.svg', raw:true, preview:'assets/downloads/icons/sun.svg'}]},
   {name:'accessibility', variants:[{label:'SVG', file:'assets/downloads/icons/accessibility.svg', raw:true, preview:'assets/downloads/icons/accessibility.svg'}]},
   {name:'info', variants:[{label:'SVG', file:'assets/downloads/icons/info.svg', raw:true, preview:'assets/downloads/icons/info.svg'}]}
  ]},
  {title:L('Motion','Animation'), items:[
   {name:L('Motion logo','Logo animé'), variants:[{label:L('Video (MP4)','Vidéo (MP4)'), file:'assets/logo/anim.mp4'}, {label:L('Outline (PNG)','Au trait (PNG)'), file:'assets/logo/motion.png', bg:'#002654'}]},
   {name:L('Logo system overview','Vue d’ensemble du système'), variants:[{label:L('Overview','Vue d’ensemble'), file:'assets/logo/system.png'}]}
  ]}
 ]},
  {t:'note', text:L('Baskerville is installed with macOS and Microsoft Office, and Arial ships with Windows and macOS: neither can be redistributed here. Libre Baskerville is the free equivalent. Montserrat and Libre Baskerville are under the SIL Open Font License; Lucide is under the ISC licence. The full Lucide library is at lucide.dev.','Baskerville est installée avec macOS et Microsoft Office, et Arial est fournie avec Windows et macOS : aucune des deux ne peut être redistribuée ici. Libre Baskerville en est l’équivalent libre. Montserrat et Libre Baskerville sont sous licence SIL Open Font ; Lucide est sous licence ISC. La bibliothèque Lucide complète est sur lucide.dev.')}
 ]}
]}];
})();
