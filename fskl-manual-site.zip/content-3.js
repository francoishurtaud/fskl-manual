(function(){
var L=function(e,f){return {en:e,fr:f}};
var R='assets/raw/', C='assets/crop/';
var IC=function(p){return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#002654" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">'+p+'</svg>');};
window.FSKL_PARTS=window.FSKL_PARTS||{};
window.FSKL_PARTS.c=[
{id:'p11', num:'10', title:L('Governance & Stewardship','Gouvernance & suivi'), intro:L('A brand manual is worth nothing until it is implemented and protected. One custodian, one asset library, one approval path, so the system holds across years and contributors.','Un manuel de marque ne vaut que s’il est appliqué et protégé. Un gardien, une bibliothèque d’actifs, un circuit de validation : ainsi le système tient dans le temps et avec des contributeurs multiples.'), sections:[
 {id:'11-2', kicker:L('10.1 · Quality assurance','10.1 · Assurance qualité'), title:L('The one-page QA card','La carte QA d’une page'), sub:L('Sits in every workspace. Run it before anything ships.','Présente dans chaque espace de travail. À utiliser avant toute publication.'), blocks:[
  {t:'qa', title:L('Check list','Checklist'), reset:L('Reset','Réinitialiser'), done:L('Ready to ship','Prêt à publier'), progress:L('checks done','contrôles faits'), reviewer:L('Reviewed by','Relu par'), reviewerPh:L('Name','Nom'), items:[
   L('Logo is from /01_LOGO/, not a re-export or screenshot','Le logo vient de /01_LOGO/, pas d’une réexportation ni d’une capture'),
   L('Colours match brand, no eyeballed values','Les couleurs correspondent à la marque, pas de valeurs estimées à l’œil'),
   L('Body type ≥ 11 pt print or 16 px screen','Corps ≥ 11 pt imprimé ou 16 px écran'),
   L('French version exists & is correctly typeset','Version française présente et correctement composée'),
   L('Children’s photos cleared against the consent list','Photos d’enfants vérifiées avec la liste de consentements'),
   L('AEFE seal placed where required, not where not','Sceau AEFE placé où requis, pas ailleurs'),
   L('Date is unambiguous, DD MM YYYY','Date sans ambiguïté, JJ MM AAAA'),
   L('Contact details point to a real, monitored mailbox','Coordonnées vers une boîte réelle et surveillée')]}
 ]}
]},

{id:'p12', num:'01', title:L('Quick Reference','Référence rapide'), intro:L('The daily-use handbook. A teacher should understand the brand in under ten minutes, the rules that keep everything on-brand without a designer in the room.','Le guide du quotidien. Un enseignant doit pouvoir comprendre la marque en moins de dix minutes, ainsi que les règles qui permettent de rester cohérent, même sans designer à ses côtés.'), sections:[
 {id:'12-1', kicker:L('1.1 · Quick reference','1.1 · Référence rapide'), title:L('The one-page QA card','La fiche de contrôle en une page'), sub:L('Sits in every workspace. Run it before anything ships.','Présente dans chaque espace de travail. À consulter avant toute publication.'), blocks:[
  {t:'cards', cols:5, items:[
   {num:'1', img:'assets/logo/land.png', imgH:150, title:L('Logos','Logos'), text:L('Official files. Clear space. Never stretch.','Fichiers officiels. Espace libre. Ne jamais étirer.'), link:'p3'},
   {num:'2', bars:true, title:L('Colours','Couleurs'), text:L('Deep Blue leads. Red 15%, Yellow 5%.','Bleu profond dominant. Rouge 15 %, jaune 5 %.'), link:'p4'},
   {num:'3', aa:true, title:L('Types','Typographies'), text:L('Baskerville titles. Montserrat or Arial.','Titres Baskerville. Texte Montserrat/Arial.'), link:'p5'},
   {num:'4', img:R+'p114_3.jpg', imgH:150, cover:true, title:L('Imagery','Images'), text:L('Real children. Natural light. Consent always.','Vrais élèves. Lumière naturelle. Consentement.'), link:'p7'},
   {num:'5', img:R+'p114_6.png', imgH:150, sun:true, title:L('Environment','Environnement'), text:L('Colour indoors. Sun: B&W. Shade: Blue.','Couleur dedans. Soleil : N&B. Ombre : bleu.'), link:'p3'}]}
 ]},
 {id:'12-2', kicker:L('1.2 · One brand, one school','1.2 · Une marque, une école'), title:L('One Brand. One School.','Une seule marque. Une seule école.'), blocks:[
  {t:'statement', size:'m', text:L('A strong identity is not created by logos or colours alone. It is created by thousands of consistent decisions made every day.\n\nEvery email, every classroom, every conversation with a family and every document contributes to the reputation of FSKL.\n\nThis manual exists to help everyone make those decisions with confidence, ensuring that the school remains recognisable, trusted and coherent for years to come.','Une identité forte ne naît pas seulement des logos ou des couleurs. Elle se construit par des milliers de décisions cohérentes, prises chaque jour.\n\nChaque courriel, chaque classe, chaque échange avec une famille et chaque document contribuent à la réputation de FSKL.\n\nCe manuel aide chacun à prendre ces décisions avec confiance, afin que l’école demeure reconnaissable, digne de confiance et cohérente dans la durée.')}
 ]}
]}
];

window.FSKL_UI={
 en:{lang:'EN', manual:'Brand Manual', edition:'EDITION V2.34.261110', era:'Eurocampus Era', coverTitle:'Brand Manual & Institutional Identity System', slogan:'French Excellence. Open to the world', confidential:'Internal. Confidential to FSKL leadership, staff, and approved partners. Do not share, do not reproduce. Prepared by François Hurtaud. October 2026.', search:'Search the manual', noResults:'No match. Try another word.', results:'results', part:'Part', contents:'Contents', start:'Start reading', quick:'Quick reference · 10 min', qa:'QA checklist', prev:'Previous', next:'Next', home:'Cover', copied:'Copied', copy:'Click to copy', play:'Play build', exit:'Play exit', breathe:'Breathing loop', bg:'Background', level1:'Level 1 · Montserrat', level2:'Level 2 · Arial', sections:'sections', close:'Close', menu:'Contents', draft:'To be discussed', review:'To be reviewed', top:'Back to top', preparedBy:'Prepared by', designedBy:'Designed by'},
 fr:{lang:'FR', manual:'Manuel de marque', edition:'ÉDITION V2.34.261110', era:'Ère Eurocampus', coverTitle:'Manuel de marque & système d’identité institutionnelle', slogan:'L’excellence française. Ouverte sur le monde.', confidential:'Interne. Confidentiel, réservé à la direction de FSKL, au personnel et aux partenaires autorisés. Ne pas partager, ne pas reproduire. Préparé par François Hurtaud. Octobre 2026.', search:'Rechercher dans le manuel', noResults:'Aucun résultat. Essayez un autre mot.', results:'résultats', part:'Partie', contents:'Sommaire', start:'Commencer la lecture', quick:'Référence rapide · 10 min', qa:'Checklist QA', prev:'Précédent', next:'Suivant', home:'Couverture', copied:'Copié', copy:'Cliquer pour copier', play:'Lire l’apparition', exit:'Lire la disparition', breathe:'Respiration en boucle', bg:'Fond', level1:'Niveau 1 · Montserrat', level2:'Niveau 2 · Arial', sections:'sections', close:'Fermer', menu:'Sommaire', draft:'À discuter', review:'À revoir', top:'Haut de page', preparedBy:'Préparé par', designedBy:'Conçu par'}
};
})();
