(function(){
var L=function(e,f){return {en:e,fr:f}};
var R='assets/raw/', C='assets/crop/';
window.FSKL_PARTS=window.FSKL_PARTS||{};
window.FSKL_PARTS.b=[
{id:'p4', num:'05', title:L('Colour System','Système couleurs'), intro:L('Most of the surface is navy or paper; colour earns its place by carrying meaning. Every accent on every page should answer the question, what does this red mean here?','La plupart des surfaces sont bleu nuit ou papier ; la couleur mérite sa place lorsqu’elle porte un sens. Chaque accent, sur chaque page, doit répondre à la question : que signifie ce rouge ici ?'), sections:[
{id:'4-1', kicker:L('5.1 · Palette','5.1 · Palette'), title:L('Colour Philosophy','Philosophie couleur'), blocks:[
  {w:[5,7], cols:[[
   {t:'p', text:L('The FSKL palette combines the colours of France and Malaysia to express the school’s unique identity.','La palette FSKL associe les couleurs de la France et de la Malaisie pour exprimer l’identité singulière de l’école.')},
   {t:'list', style:'bullet', items:[
    L('**French Deep Blue** represents knowledge, trust and academic excellence.','Le **bleu profond français** représente le savoir, la confiance et l’excellence académique.'),
    L('**Malaysian Red** brings energy, confidence and ambition.','Le **rouge malaisien** apporte énergie, assurance et ambition.'),
    L('**Malaysian Yellow** symbolises achievement and optimism.','Le **jaune malaisien** symbolise la réussite et l’optimisme.'),
    L('**Vellum** and **White** provide clarity and space.','Le **vélin** et le **blanc** offrent clarté et espace.'),
    L('**Near Black** adds strength and sophistication.','Le **noir profond** apporte force et élégance.')]},
   {t:'p', text:L('The result is a balanced and enduring colour system that reflects both heritage and progress.','Il en résulte un système couleur équilibré et durable, qui reflète à la fois l’héritage et le mouvement.')}
  ],[
   {t:'images', cols:2, items:[{src:R+'p041_1.png', fit:'contain', h:110, cap:L('Flag blue vs FSKL Deep Blue','Bleu du drapeau et bleu profond FSKL')},{src:R+'p041_2.jpg', fit:'contain', h:110, cap:L('Malaysia','Malaisie')}]}
  ]]}
 ]},
 {id:'4-2', kicker:L('5.2 · Colour proportion','5.2 · Proportion des couleurs'), title:L('Colour proportion','Proportion des couleurs'), sub:L('Click a value to copy it. Use these exact values, never eyeballed ones.','Cliquez sur une valeur pour la copier. Utilisez ces valeurs exactes, jamais des valeurs estimées à l’œil.'), blocks:[
  {t:'swatches', items:[
   {name:L('French Deep Blue','Bleu profond français'), bg:'#002654', fg:'#FFFFFF', codes:['#002654',['RGB','0 38 84'],['Pantone','280 C']], tints:true, use:L('20% · Mark, headings, CTAs, navigation','20 % · Marque, titres, CTA, navigation')},
   {name:L('Malaysian Red','Rouge malaisien'), bg:'#CC0000', fg:'#FFFFFF', codes:['#CC0000',['RGB','204 0 0'],['Pantone','485 C']], tints:true, use:L('15% · Accents, hover, rooster comb','15 % · Accents, survol, crête du coq')},
   {name:L('Malaysian Yellow','Jaune malaisien'), bg:'#FFD100', fg:'#111111', codes:['#FFD100',['RGB','255 209 0'],['Pantone','109 C']], tints:true, use:L('5% · Highlights, rooster, pull quotes','5 % · Mises en avant, coq, citations')},
   {name:L('Vellum','Vélin'), bg:'#F9F1EC', fg:'#111111', codes:['#F9F1EC',['RGB','249 241 236']], use:L('Page ground · print · brochures','Fond de page · impression · brochures')},
   {name:L('White','Blanc'), bg:'#FFFFFF', fg:'#111111', codes:['#FFFFFF',['RGB','255 255 255']], use:L('Cards · clear space · reversed type','Cartes · espace libre · texte en réserve')},
   {name:L('Near Black','Noir profond'), bg:'#111111', fg:'#FFFFFF', codes:['#111111',['RGB','17 17 17'],['CMYK','0 0 0 93']], tints:true, use:L('Body text · monochrome mark','Texte courant · marque monochrome')}]},
  {t:'donuts', charts:[{title:L('Proportion on a typical surface','Proportion sur une surface type'), center:L('Colour ratio','Ratio couleur'), items:[
   {name:L('Vellum & White','Vélin & blanc'), pct:55, bg:'#F9F1EC'},
   {name:L('French Deep Blue','Bleu profond français'), pct:20, bg:'#002654'},
   {name:L('Malaysian Red','Rouge malaisien'), pct:15, bg:'#CC0000'},
   {name:L('Malaysian Yellow','Jaune malaisien'), pct:5, bg:'#FFD100'},
   {name:L('Near Black','Noir profond'), pct:5, bg:'#111111'}]}]},
  {t:'ratio', title:L('The same proportion as a bar','La même proportion en barre'), items:[
   {name:L('French Deep Blue','Bleu profond français'), pct:20, bg:'#002654'},
   {name:L('Malaysian Red','Rouge malaisien'), pct:15, bg:'#CC0000'},
   {name:L('Malaysian Yellow','Jaune malaisien'), pct:5, bg:'#FFD100'},
   {name:L('Vellum & White','Vélin & blanc'), pct:55, bg:'#F9F1EC'},
   {name:L('Near Black','Noir profond'), pct:5, bg:'#111111'}]},
  {t:'h', text:L('Colour in use','La couleur en situation')},
  {t:'layoutex', lbl:{web:L('Web page','Page web'), print:L('Print poster','Affiche imprimée'), headline:L('Excellence française, ailleurs.','Excellence française, ailleurs.'), cta:L('Book a visit','Réserver une visite'), webNote:L('White and vellum carry the page; navy anchors the hero; red is reserved for the single action; yellow is a small highlight.','Le blanc et le vélin portent la page ; le bleu nuit ancre le héros ; le rouge est réservé à l’action unique ; le jaune reste un petit accent.'), printNote:L('Vellum ground, navy headline, one red rule, black body text, a single yellow highlight.','Fond vélin, titre bleu nuit, un filet rouge, texte noir, un seul accent jaune.')}}
 ]}
]},

{id:'p5', num:'06', title:L('Typography','Typographie'), intro:L('Typography carries 80% of the brand’s daily character.','La typographie porte 80 % du caractère quotidien de la marque.'), sections:[
 {id:'5-1', kicker:L('6.1 · Two levels','6.1 · Deux niveaux'), title:L('Marketing & Operational','Marketing & opérationnel'), blocks:[
  {t:'levels', items:[
   {label:L('Level 1','Niveau 1'), sub:L('For Marketing & Brand Expression','Pour le marketing & l’expression de marque'), sans:'Montserrat', sansStack:'Montserrat, Arial, sans-serif', text:L('Brand-controlled. Montserrat Alternates (wordmark), Baskerville (headings), Montserrat (body). For communications, admissions, agencies, website, brand films and all touchpoint executed by marketing internally or externally.','Contrôlé par la marque. Montserrat Alternates (marque verbale), Baskerville (titres), Montserrat (texte courant). Pour la communication, les admissions, les agences, le site web, les films de marque et tous les points de contact réalisés par le marketing, en interne ou en externe.')},
   {label:L('Level 2','Niveau 2'), sub:L('For Operational usage - School & Admin','Pour les usages opérationnels, école & administration'), sans:'Arial', sansStack:'Arial, Helvetica, sans-serif', text:L('Operational and staff. Baskerville (headings), Arial (body). Teachers & admin, daily, in Google Workspace, Office & Canva. Installed everywhere, zero friction, zero installation.','Opérationnel et personnel. Baskerville (titres), Arial (texte courant). Enseignants & administration, au quotidien, dans Google Workspace, Office & Canva. Installées partout : aucune friction, aucune installation.')}]}
 ]},
 {id:'5-2', kicker:L('6.2 · Display & headings','6.2 · Titres & grands formats'), title:'Baskerville', blocks:[
  {t:'specimen', items:[
   {name:'Baskerville', stack:'Baskerville, "Libre Baskerville", Georgia, serif', level:L('Levels 1 & 2','Niveaux 1 & 2'), tag:L('Heritage. Elegance. Authority.','Héritage. Élégance. Autorité.'), desc:L('A refined serif with classic proportions and graceful details. Used to convey heritage, credibility, and a sense of permanence. We use it for headlines, key messages, quotes, diploma titles and signage','Une sérif raffinée, aux proportions classiques et aux détails gracieux. Elle exprime l’héritage, la crédibilité et la permanence. Nous l’utilisons pour les titres, messages clés, citations, intitulés de diplômes et signalétique.')}]}
 ]},
 {id:'5-3', kicker:L('6.3 · The sans serifs','6.3 · Les sans-serif'), title:'Montserrat & Arial', sub:L('Two neutral sans-serif designed for maximum readability. Used for everyday communication, body text, navigation, and digital applications.','Deux sans-serif neutres conçues pour une lisibilité maximale. Utilisées pour la communication quotidienne, les textes courants, la navigation et les supports numériques.'), blocks:[
  {t:'specimen', items:[
   {name:'Montserrat', stack:'Montserrat, Arial, sans-serif', level:L('Level 1 - For Marketing & Brand Expression','Niveau 1 - Pour le marketing & l’expression de marque'), tag:L('Clarity. Accessibility. Modernity.','Clarté. Accessibilité. Modernité.')},
   {name:'Arial', stack:'Arial, Helvetica, sans-serif', level:L('Level 2 - For Operational usage - School & Admin','Niveau 2 - Pour les usages opérationnels école & administration'), tag:L('Clarity. Accessibility. Modernity.','Clarté. Accessibilité. Modernité.')}]}
 ]},
 {id:'5-5', kicker:L('6.4 · Typographic hierarchy','6.4 · Hiérarchie typographique'), title:L('Eight levels, one rhythm','Huit niveaux, un rythme'), sub:L('Switch level to preview the hierarchy with the Level 1 (Montserrat) or Level 2 (Arial) sans.','Changez de niveau pour prévisualiser la hiérarchie avec la sans du niveau 1 (Montserrat) ou du niveau 2 (Arial).'), blocks:[
  {w:[8,4], cols:[[
   {t:'typescale', rows:[
    {sample:L('Hero headline','Titre héro'), spec:L('H0 · Baskerville Regular · 60–96 pt','H0 · Baskerville Regular · 60–96 pt'), serif:true, size:56, weight:400, lh:1.05},
    {sample:L('Major section','Grande section'), spec:L('H1 · Baskerville Bold · 36 pt','H1 · Baskerville Bold · 36 pt'), serif:true, size:36, weight:700, lh:1.15},
    {sample:L('Subsection heading','Titre de sous-section'), spec:L('H2 · Montserrat or Arial SemiBold · 22 pt','H2 · Montserrat ou Arial SemiBold · 22 pt'), size:22, weight:600, lh:1.25},
    {sample:L('Tertiary heading','Titre tertiaire'), spec:L('H3 · Montserrat or Arial Medium · 16 pt','H3 · Montserrat ou Arial Medium · 16 pt'), size:16, weight:500, lh:1.3},
    {sample:L('Kicker','Surtitre'), spec:L('H4 · Montserrat or Arial SemiBold caps · +80','H4 · Montserrat ou Arial SemiBold caps · +80'), size:12, weight:600, caps:true, lh:1.3},
    {sample:L('Default reading text','Texte de lecture courant'), spec:L('Body · Montserrat or Arial Regular · 10.5–11 pt','Corps · Montserrat ou Arial Regular · 10,5–11 pt'), size:16, weight:400, lh:1.45},
    {sample:L('Image caption & metadata','Légende d’image & métadonnées'), spec:L('Caption · Italic · 9 pt','Légende · Italic · 9 pt'), size:13, weight:400, italic:true, lh:1.4}]}
  ],[
   {t:'images', cols:1, items:[{src:R+'p048_1.png', fit:'contain', h:420, cap:L('The hierarchy applied to a web page','La hiérarchie appliquée à une page web')}]}
  ]]}
 ]},
 {id:'5-6', kicker:L('6.5 · Body type','6.5 · Texte courant'), title:L('Where the brand spends 80% of its surface','Là où la marque occupe 80 % de sa surface'), blocks:[
  {w:[7,5], cols:[[
   {t:'lead', size:'s', text:L('Body type is set generously, comfortable line-height, comfortable measure. FSKL is a school of long-form thought; we are not in the business of dense corporate slides. Read the long sentence.','Le texte courant se compose avec générosité : interligne confortable, longueur de ligne confortable. FSKL est une école de pensée longue ; nous ne produisons pas des diapositives d’entreprise surchargées. Lisez la phrase longue.')},
   {t:'table', key:true, rows:[
    [L('1. Body size','1. Taille du corps'), L('10.5–11 pt · 16 px screen','10,5–11 pt · 16 px écran')],
    [L('2. Line-height','2. Interligne'), '1.2 ×'],
    [L('3. Measure','3. Longueur de ligne'), L('60–75 characters','60–75 caractères')],
    [L('4. Paragraphs','4. Paragraphes'), L('Vertical gap, no first-line indent','Espacement vertical, pas de retrait de première ligne')],
    [L('5. Tables','5. Tableaux'), L('Horizontal rules only · tabular figures','Filets horizontaux seulement · chiffres tabulaires')],
    [L('6. Forms','6. Formulaires'), L('Labels above · Rouge required','Libellés au-dessus · rouge obligatoire')]]}
  ],[
   {t:'images', cols:1, items:[{src:R+'p048_1.png', fit:'contain', h:420, cap:L('The hierarchy applied to a web page','La hiérarchie appliquée à une page web')}]}
  ]]}
 ]},
 {id:'5-7', kicker:L('6.6 · Bilingual typography','6.6 · Typographie bilingue'), title:L('Two Grammars','Deux grammaires'), blocks:[
  {t:'p', text:L('The dominant language sets the page’s conventions. French is always either the original or visibly equal, never positioned as a translation, except on the website where EN is appearing first.','La langue dominante fixe les conventions de la page. Le français est toujours soit la langue d’origine, soit visiblement à égalité ; il n’est jamais présenté comme une traduction, sauf sur le site web où l’EN apparaît en premier.')},
  {t:'cards', cols:2, items:[
   {flag:R+'p050_1.jpg', title:L('Français','Français'), text:L('Espace fine insécable before : ; ! ?\nGuillemets « comme ceci »\nSentence case in titles, not Title Case.','Espace fine insécable avant : ; ! ?\nGuillemets « comme ceci »\nCasse de phrase dans les titres, pas de Title Case.'), example:'Bienvenue à l’Eurocampus !'},
   {flag:R+'p050_2.jpg', title:L('English','Anglais'), text:L('No space before high punctuation.\nCurly quotes “like this”\nTitle Case for headlines.','Pas d’espace avant la ponctuation haute.\nGuillemets anglais “like this”\nTitle Case pour les titres.'), example:'Welcome to the Eurocampus!'}]}
 ]},
 {id:'5-8', kicker:L('6.7 · Fallback fonts','6.7 · Police de secours'), title:L('Fallback Fonts','Police de secours'), sub:L('Using a fallback is a normal operating condition, not a failure.','Utiliser une police de secours est une condition normale d’exploitation, pas un échec.'), blocks:[
  {w:[7,5], cols:[[
   {t:'fallback', title:L('Intended → Fallback chain','Intention → chaîne de secours'), rows:[
    {name:'Baskerville', chain:[{n:'Libre Baskerville', s:'"Libre Baskerville", Georgia, serif'},{n:'Georgia', s:'Georgia, serif'}], s:'Baskerville, "Libre Baskerville", Georgia, serif'},
    {name:'Montserrat', chain:[{n:'Arial', s:'Arial, sans-serif'}], s:'Montserrat, Arial, sans-serif'},
    {name:'Arial', chain:[{n:'Universal', s:'Arial, sans-serif'},{n:'Helvetica', s:'Helvetica, Arial, sans-serif'}], s:'Arial, Helvetica, sans-serif'}]},
   {t:'rule', text:L('Emergency: on a borrowed laptop, Georgia + Arial stays on-brand. On a Chromebook, Arial Bold + Regular carries the hierarchy. Hierarchy is enough.','Urgence : sur un ordinateur emprunté, Georgia + Arial reste conforme à la marque. Sur Chromebook, Arial Bold + Regular suffit à porter la hiérarchie. La hiérarchie suffit.')}
  ],[
   {t:'h', text:L('Forbidden, always:','Interdit, toujours :')},
   {t:'list', style:'dont', items:[
    {text:L('Times New Roman as first choice','Times New Roman en premier choix'), font:'"Times New Roman", Times, serif'},
    {text:L('Calibri - Office-generic','Calibri, générique Office'), font:'Calibri, Carlito, sans-serif'},
    {text:L('Comic Sans, anywhere, ever','Comic Sans, partout, toujours interdit'), font:'"Comic Sans MS", "Comic Sans", cursive'},
    {text:L('Papyrus & decorative scripts','Papyrus & polices décoratives'), font:'Papyrus, fantasy'}]}
  ]]}
 ]}
]},

{id:'p6', num:'07', title:L('Graphic Language','Langage graphique'), intro:L('The connective tissue of the brand, everything that is not the logo, the colours, or the type. It is what makes a poster, a school report, and a uniform polo feel like one family.','Le tissu de liaison de la marque : tout ce qui n’est pas le logo, les couleurs ou la typographie. C’est ce qui fait qu’une affiche, un bulletin scolaire et un polo d’uniforme appartiennent à la même famille.'), sections:[
 {id:'6-1', kicker:L('7.1 · The campus flags','7.1 · Les drapeaux du campus'), title:L('Graphic Anchor','Ancrage graphique'), sub:L('We use the splines and curves of the flags as our signature graphic element. The shapes can define masks, backgrounds, or be used as single-line graphic elements.','Nous utilisons les courbes et lignes souples des drapeaux comme élément graphique de signature. Ces formes peuvent définir des masques, des fonds ou être utilisées comme éléments graphiques en trait simple.'), blocks:[
  {t:'images', cols:1, items:[{src:C+'c53.jpg', h:300, fit:'contain', bg:'#F9F1EC', cap:L('The shade-sail flags of the campus, traced into line and shape.','Les voiles d’ombrage du campus, transformées en traits et en formes.')}]}
 ]},
 {id:'6-2', kicker:L('7.2 · Signature pictograms','7.2 · Pictogrammes de signature'), title:L('Two Symbols','Deux symboles'), sub:L('We use our hevea leaf and coq as symbols to be embedded for large scale background or patterns.','Nous utilisons la feuille d’hévéa et le coq comme symboles intégrés dans les grands fonds ou motifs.'), blocks:[
  {t:'cards', cols:2, items:[
   {img:'assets/logo/hevea-navy.png', imgH:200, title:L('Hevea leaf','Feuille d’hévéa'), text:L('We use HEVEA leaf as symbol of growth, ideal for HEVEA Campus marketing materials','Nous utilisons la feuille d’hévéa comme symbole de croissance, idéal pour les supports de communication du campus HEVEA.')},
   {img:'assets/logo/coq-navy.png', imgH:200, title:L('Rooster','Coq'), text:L('We use our rooster as a symbol of resilience, perseverance and French heritage.','Nous utilisons notre coq comme symbole de résilience, de persévérance et d’héritage français.')}]}
 ]},
 {id:'6-3', kicker:L('7.2 · Patterns and textures','7.2 · Motifs et textures'), title:L('Patterns and Textures','Motifs et textures'), blocks:[
  {w:[6,6], cols:[[
   {t:'lead', size:'s', text:L('The brand has a single official pattern: the Hevea Pattern, a low-density repeat of stylised hevea leaves at 30% Bleu Nuit on Vellum.','La marque possède un seul motif officiel : le motif Hévéa, une répétition légère de feuilles d’hévéa stylisées à 30 % Bleu Nuit sur Vélin.')},
   {t:'h', text:L('The pattern is used:','Le motif s’utilise :')},
   {t:'list', style:'do', items:[
    L('As an endpaper texture in printed publications','Comme texture de garde dans les publications imprimées'),
    L('As a subtle background fill in Bleu Nuit cards (very low opacity)','Comme fond discret dans les cartes Bleu Nuit (très faible opacité)'),
    L('As wrapping paper for school merchandise','Comme papier d’emballage pour les produits de l’école'),
    L('As a textile pattern (linings, ties)','Comme motif textile (doublures, cravates)')]},
   {t:'h', text:L('The pattern is not used as:','Le motif ne s’utilise pas :')},
   {t:'list', style:'dont', items:[
    L('A web page background','En fond de page web'),
    L('A full-bleed background behind any logo','En fond pleine page derrière un logo'),
    L('A repeating tile across signage','En répétition sur la signalétique')]}
  ],[
   {t:'images', cols:1, items:[{src:R+'p058_1.jpg', h:520}]}
  ]]}
 ]}
]},

{id:'p7', num:'08', title:L('Photography & Videography','Photographie & vidéo'), intro:L('If typography carries the brand’s voice, photography carries its truth. A school cannot fake its own community. FSKL’s images look like the school looking at itself.','Si la typographie porte la voix de la marque, la photographie en porte la vérité. Une école ne peut pas imiter sa propre communauté. Les images de FSKL donnent l’impression que l’école se regarde elle-même.'), sections:[
 {id:'7-1', kicker:L('8.1 · Photographic philosophy','8.1 · Philosophie photographique'), title:L('Documentary, calm, human','Documentaire, calme, humaine'), blocks:[
  {w:[7,5], cols:[[
   {t:'images', cols:1, items:[{src:R+'p060_1.jpg', h:420}]}
  ],[
   {t:'list', style:'do', items:[
    L('Available light, no on-camera flash. Malaysian light is light-filled.','Lumière disponible, pas de flash direct. La lumière malaisienne est abondante.'),
    L('Eye level for children, slightly below. Never en contre-plongé.','À hauteur d’enfant, ou légèrement plus bas. Jamais en contre-plongée.'),
    L('Faces and hands, the most readable parts of the frame.','Visages et mains, les parties les plus lisibles du cadre.'),
    L('Restrained smiles, a genuine half-smile beats a forced grin.','Sourires retenus : un vrai demi-sourire vaut mieux qu’un grand sourire forcé.')]},
   {t:'list', style:'dont', items:[
    L('Models & staged “diverse group portrait”','Modèles & portraits de groupe « divers » mis en scène'),
    L('Forced smiles & generic education clichés','Sourires forcés & clichés éducatifs génériques')]},
   {t:'rule', text:L('Real children · Real classrooms · Real days','Vrais enfants · Vraies classes · Vraies journées')}
  ]]},
  {t:'h', text:L('Technical direction','Direction technique')},
  {w:[5,7], cols:[[
   {t:'images', cols:1, items:[{src:R+'p061_1.jpg', h:340}]}
  ],[
   {t:'table', head:[L('Parameter','Paramètre'), L('Direction','Direction')], rows:[
    [L('Format','Format'), L('Full-frame digital (Sony A7 / Canon R / Nikon Z series). Medium format permissible for portraiture.','Numérique plein format (Sony A7 / Canon R / Nikon Z). Moyen format permis pour le portrait.')],
    [L('Lens choices','Objectifs'), L('35mm or 50mm prime preferred for environmental portraiture; 85mm for tight portraits; 24mm for wide environment; 70-200mm for sports / events.\n**No fisheye. No extreme wide-angle for portraiture.**','35 mm ou 50 mm fixe privilégié pour les portraits en contexte ; 85 mm pour les portraits serrés ; 24 mm pour les environnements larges ; 70-200 mm pour sport / événements.\n**Pas de fisheye. Pas de très grand-angle extrême pour le portrait.**')],
    [L('Aperture','Ouverture'), L('f/2.0–f/4.0 for environmental portraits; f/5.6–f/8.0 for group shots; f/4.0–f/5.6 for classroom interiors.','f/2.0–f/4.0 pour les portraits en contexte ; f/5.6–f/8.0 pour les groupes ; f/4.0–f/5.6 pour les intérieurs de classe.')],
    [L('ISO','ISO'), L('As low as possible, capped at 6400. Grain is acceptable; **smearing from over-noise-reduction is not.**','Aussi bas que possible, plafonné à 6400. Le grain est acceptable ; **le lissage dû à une réduction de bruit excessive ne l’est pas.**')],
    [L('Aspect ratios','Ratios'), L('3:2 for editorial. 4:5 for Instagram feed. 9:16 for stories and Reels. 16:9 for video and YouTube. 1:1 for grid composition and certain print uses.','3:2 pour l’éditorial. 4:5 pour le fil Instagram. 9:16 pour stories et Reels. 16:9 pour vidéo et YouTube. 1:1 pour compositions en grille et certains usages imprimés.')]]}
  ]]}
 ]},
 {id:'7-4', kicker:L('8.4 · Subject categories','8.4 · Catégories de sujets'), title:L('Five briefs, refreshed annually','Cinq briefs, renouvelés chaque année'), blocks:[
  {t:'cards', cols:5, items:[
   {photo:R+'p062_1.jpg', label:'CAT-A', title:L('Portraiture','Portraits'), text:L('• Student portraits, teacher portraits, leadership portraits.\n• 3:2 or 4:5 framing; subject occupies the central vertical third.\n• Background: a school interior surface (classroom wall, library shelf, courtyard), never a seamless studio backdrop except for the Head’s official portrait.\n• Eye contact: 50/50 between camera-direct and slightly-off-camera.','• Portraits d’élèves, d’enseignants et de la direction.\n• Cadrage 3:2 ou 4:5 ; le sujet occupe le tiers vertical central.\n• Fond : surface intérieure de l’école (mur de classe, rayonnage de bibliothèque, cour), jamais de fond studio sans couture sauf pour le portrait officiel du Proviseur.\n• Regard : 50/50 entre regard caméra et regard légèrement hors champ.')},
   {photo:R+'p062_2.jpg', label:'CAT-B', title:L('Classroom & Learning','Classe & apprentissages'), text:L('• Children at work, not posed.\n• Hands in frame whenever possible, writing, building, drawing.\n• Teacher visible but not necessarily in focus.\n• Avoid the cliché of “child raising hand with bright smile.”','• Des enfants au travail, non posés.\n• Mains dans le cadre dès que possible : écrire, construire, dessiner.\n• Enseignant visible, sans être nécessairement net.\n• Éviter le cliché de « l’enfant qui lève la main avec un grand sourire ».')},
   {photo:R+'p062_3.jpg', label:'CAT-C', title:L('Campus & Environment','Campus & environnement'), text:L('• Architectural photography of the campus.\n• Shot in early morning or late afternoon light.\n• Always at human eye-level, no drone shots in brand-expression library except for the established annual aerial campus shot.','• Photographie architecturale du campus.\n• Prise de vue tôt le matin ou en fin d’après-midi.\n• Toujours à hauteur humaine, pas de drone dans la bibliothèque d’expression de marque sauf pour la vue aérienne annuelle établie du campus.')},
   {photo:R+'p062_4.jpg', label:'CAT-D', title:L('Events, Sport & Community','Événements, sport & communauté'), text:L('• Graduations, parent evenings, cultural festivals, sports day.\n• Documentary, photojournalistic register.\n• Faces of several people in frame; do not isolate a single child unless their parent has signed a specific consent.\n• Movement is acceptable slight motion blur conveys energy more than a frozen mid-jump.\n• Tilt is also acceptable to convey action','• Remises de diplômes, soirées parents, fêtes culturelles, journée sportive.\n• Registre documentaire, photojournalistique.\n• Visages de plusieurs personnes dans le cadre ; ne pas isoler un enfant seul sauf consentement spécifique des parents.\n• Le mouvement est acceptable : un léger flou traduit mieux l’énergie qu’un saut figé.\n• L’inclinaison est également possible pour traduire l’action.')},
   {photo:R+'p062_5.jpg', label:'CAT-E', title:L('Editorial & Conceptual','Éditorial & conceptuel'), text:L('• Used for annual reports, prospectus features.\n• More composed, achievement, slower-shot images. Still life of student work; close-ups of writing in progress; archive material re-photographed.\n• These images often have no people, they carry the institution’s atmosphere.','• Utilisé pour rapports annuels et dossiers de prospectus.\n• Images plus composées, orientées réussite, prises plus lentement. Natures mortes de travaux d’élèves ; gros plans d’écriture en cours ; archives rephotographiées.\n• Ces images n’ont souvent pas de personnes ; elles portent l’atmosphère de l’institution.')}]}
 ]},
 {id:'7-5', kicker:L('8.5 · Grading & forbidden styles','8.5 · Étalonnage & styles interdits'), title:L('One defined grade','Un rendu défini'), blocks:[
  {w:[7,5], cols:[[
   {t:'compare', items:[{src:R+'p063_1.jpg'},{src:R+'p063_3.jpg'},{src:R+'p063_2.jpg'}], lbl:{before:L('Before','Avant'), after:L('After','Après'), slider:L('Drag to compare','Faites glisser pour comparer')}, note:L('Drag the handle to compare. The “Before” is a simulated ungraded look; the “After” applies the FSKL grade.','Faites glisser la poignée pour comparer. L’« Avant » simule un rendu non étalonné ; l’« Après » applique l’étalonnage FSKL.')}
  ],[
   {t:'list', style:'do', items:[
    L('Warm natural colour temperature, sunlit, Vellum-creamy whites.','Température naturelle chaude, lumière solaire, blancs crémeux de type Vélin.'),
    L('+5-10 Exposure. +10-25 contrast. -10% highlight. +10% Texture, -10% Clarity. No grain','+5-10 exposition. +10-25 contraste. -10 % hautes lumières. +10 % texture, -10 % clarté. Pas de grain.'),
    L('Rich warm skin tones','Teints riches et chaleureux.'),
    L('Deep, neutral shadows tinted slightly towards Bleu Nuit.','Ombres profondes, neutres, légèrement orientées vers le Bleu Nuit.'),
    L('Saturation reduced 3–5%, no hyper-saturated “Instagram” look, vibrancy slightly higher to 5-10%','Saturation réduite de 3–5 %, pas d’effet « Instagram » hyper-saturé ; vibrance légèrement plus élevée, 5-10 %.')]},
   {t:'list', style:'dont', items:[
    L('Lens flares, light leaks, IG presets','Flares, fuites de lumière, préréglages IG'),
    L('Stock photography for “children at FSKL”','Photos de stock pour « enfants à FSKL »')]}
  ]]}
 ]},
 {id:'7-6', kicker:L('8.6 · Privacy, diversity & AI','8.6 · Vie privée, diversité & IA'), title:L('Privacy, Diversity & AI','Vie privée, diversité & IA'), sub:L('Photograph the real classroom. Audit the library annually so the school’s actual demographic mix is reflected, never engineer a diversity ratio for a shoot.','Photographier la vraie classe. Auditer la bibliothèque chaque année afin que la diversité réelle de l’école soit reflétée ; ne jamais fabriquer un ratio de diversité pour une séance.'), blocks:[
  {t:'cards', cols:2, items:[
   {photo:R+'p064_2.jpg', title:L('Consent is non-negotiable','Le consentement n’est pas négociable'), text:L('Brand photography requires signed photo-consent on file for the year.\n\nNon-consented children appear only in non-identifiable wide shots. Captions carry first name, grade, and year only, “Léa, CE2, 2025.” Metadata is stripped before publication.','Toute photographie de marque exige un consentement photo signé et à jour pour l’année.\n\nLes enfants sans consentement n’apparaissent que dans des plans larges non identifiables. Les légendes indiquent seulement prénom, classe et année : « Léa, CE2, 2025. » Les métadonnées sont supprimées avant publication.')},
   {photo:R+'p064_1.jpg', title:L('AI imagery, strict & durable','Images IA : règle stricte et durable'), text:L('AI-generated images of human beings are forbidden in all materials, a school’s photography must depict its actual people.\n\nAI is permitted only for non-representational spot illustration, backgrounds, and textures, with Custodian approval and colophon disclosure, and for event posters','Les images générées par IA représentant des êtres humains sont interdites dans tous les supports : la photographie d’une école doit montrer ses personnes réelles.\n\nL’IA n’est autorisée que pour des illustrations non figuratives, fonds et textures, avec accord du gardien et mention au colophon, ainsi que pour des affiches d’événements.')}]}
 ]},
 {id:'7-7', kicker:L('8.7 · Styling','8.7 · Style'), title:L('Styling','Style'), blocks:[
  {w:[6,6], cols:[[
   {t:'p', text:L('The school does not “style” its own community for photography. But it does maintain standards:','L’école ne « stylise » pas sa propre communauté pour la photographie. Mais elle maintient des standards :')},
   {t:'list', style:'check', items:[
    L('Uniforms are clean and correctly worn during shoots.','Les uniformes sont propres et correctement portés pendant les prises de vue.'),
    L('Hair is brushed; collars are not askew.','Les cheveux sont coiffés ; les cols ne sont pas de travers.'),
    L('Backpacks, water bottles, and visible branding from competitor products are not in frame.','Sacs, gourdes et marques visibles de produits concurrents ne sont pas dans le cadre.'),
    L('The campus itself is tidy during shoot days, a campus-clean day is scheduled monthly.','Le campus lui-même est rangé les jours de prise de vue ; une journée campus propre est prévue chaque mois.')]},
   {t:'images', cols:1, items:[{src:R+'p065_1.jpg', h:300}]}
  ],[
   {t:'h', text:L('Forbidden Photographic Styles:','Styles photographiques interdits :')},
   {t:'list', style:'dont', items:[
    L('HDR processing (tonemapped, “halo” look).','Traitement HDR (tonemapping, effet « halo »).'),
    L('Selective colour (e.g., black-and-white with one red object).','Couleur sélective (par ex. noir et blanc avec un seul objet rouge).'),
    L('Heavy vignetting beyond a subtle natural lens fall-off.','Vignettage marqué au-delà d’une chute optique naturelle discrète.'),
    L('Photo composites that combine multiple images of children to make “the perfect group photo.”','Photomontages combinant plusieurs images d’enfants pour créer « la photo de groupe parfaite ».'),
    L('Stock photography for any brand-expression use. (Stock is permitted only for editorial fillers, abstract textures, generic city, etc. never for “children at FSKL.”)','Photographie de stock pour tout usage d’expression de marque. (Le stock n’est permis que pour des compléments éditoriaux, textures abstraites, ville générique, etc., jamais pour « les enfants à FSKL ».)'),
    L('Lens flares, light leaks, film-emulation overlays beyond the approved LUT.','Flares, fuites de lumière, surcouches d’émulation film au-delà du LUT approuvé.'),
    L('Faux-Polaroid borders, Instagram filters, social-media presets.','Bords faux-Polaroid, filtres Instagram, presets réseaux sociaux.')]}
  ]]}
 ]},
 {id:'7-8', kicker:L('8.8 · Campus photography','8.8 · Photographie du campus'), title:L('Campus Photography (Architecture)','Photographie du campus (architecture)'), blocks:[
  {w:[5,7], cols:[[
   {t:'lead', size:'s', text:L('The campus is photographed as an architectural subject in its own right.','Le campus est photographié comme un sujet architectural à part entière.')},
   {t:'list', style:'bullet', items:[
    L('Shot in the “magic hour” before assembly (07:00–07:45) or after dismissal (16:00–17:30 in tropical light).','Prise de vue à « l’heure dorée » avant le rassemblement (07:00–07:45) ou après la sortie (16:00–17:30 en lumière tropicale).'),
    L('__Symmetrical__ hallways: shot on axis, vanishing-point composition.','Couloirs __symétriques__ : prise de vue dans l’axe, composition au point de fuite.'),
    L('Library: shot at __human reading height__, eye-level seated.','Bibliothèque : prise de vue à __hauteur humaine de lecture__, au niveau des yeux assis.'),
    L('Sports facilities: shot with at least one student or __coach visible__, empty fields read as abandoned.','Équipements sportifs : prise de vue avec au moins un élève ou un __coach visible__, les terrains vides paraissent abandonnés.')]}
  ],[
   {t:'images', cols:1, items:[{src:R+'p066_1.jpg', h:420}]}
  ]]}
 ]},
 {id:'7-12', kicker:L('8.12 · Video direction','8.12 · Direction vidéo'), title:L('Video Direction','Direction vidéo'), sub:L('Video is now a primary brand channel. Direction follows the same philosophy as photography.','La vidéo est désormais un canal de marque principal. Sa direction suit la même philosophie que la photographie.'), blocks:[
  {w:[4,4,4], cols:[[
   {t:'h', text:L('Visual','Visuel')},
   {t:'list', style:'bullet', items:[
    L('Aspect: 16:9 master; 9:16 vertical secondary; 4:5 social secondary.','Format : master 16:9 ; vertical 9:16 secondaire ; social 4:5 secondaire.'),
    L('Frame rate: 24 fps for cinematic / brand films; 30 fps for documentary; 60 fps for sports.','Cadence : 24 i/s pour films cinématographiques / de marque ; 30 i/s pour documentaire ; 60 i/s pour sport.'),
    L('Color: graded to do','Couleur : étalonnage à finaliser'),
    L('Camera movement: locked tripod (most shots), slow gimbal pans, no handheld unless deliberately documentary.','Mouvement caméra : trépied fixe (la plupart des plans), lents panoramiques au stabilisateur, pas de caméra portée sauf intention documentaire.'),
    L('Cuts: long takes preferred; average shot length 4–8 seconds.','Coupes : plans longs privilégiés ; durée moyenne 4–8 secondes.')]}
  ],[
   {t:'h', text:L('Voiceover','Voix off')},
   {t:'list', style:'bullet', items:[
    L('Recorded by an FSKL voice: a teacher, a student, an alumna, **not a hired voice actor.**','Enregistrée par une voix FSKL : enseignant, élève, ancienne élève, **pas un comédien voix off.**'),
    L('French voiceover for French/AEFE audiences. English voiceover for international audiences.','Voix off française pour publics français/AEFE. Voix off anglaise pour publics internationaux.'),
    L('Subtitled in the other language always, even when the audience is single-language.','Sous-titres systématiques dans l’autre langue, même pour un public monolingue.')]},
   {t:'h', text:L('Motion Pacing and Transitions','Rythme et transitions')},
   {t:'list', style:'bullet', items:[
    L('Default cut: straight cut. No cross-dissolves except in nostalgic / archival sequences.','Coupe par défaut : coupe franche. Pas de fondus enchaînés sauf séquences nostalgiques / archives.'),
    L('Transition between scenes: black 12-frame held card is acceptable for chapter transitions.','Transition entre scènes : carton noir de 12 images acceptable pour les chapitres.'),
    L('Whip pans, lens flares, glitch transitions, animated swipes: **forbidden.**','Whip pans, flares, glitch, balayages animés : **interdits.**'),
    L('Title cards: Baskerville Regular, 60–80 pt, white-knockout on Bleu Nuit, fade in 400 ms, hold 2.4 s, fade out 400 ms.','Cartons-titres : Baskerville Regular, 60–80 pt, blanc en réserve sur Bleu Nuit, fondu entrant 400 ms, maintien 2,4 s, fondu sortant 400 ms.')]}
  ],[
   {t:'h', text:L('Audio','Audio')},
   {t:'list', style:'bullet', items:[
    L('Never camera-built-in microphone.','Jamais de micro intégré caméra.'),
    L('Ambient sound retained at low level under voiceover.','Ambiance conservée à faible niveau sous la voix off.'),
    L('Sonic logo / audio mnemonic: To-do. (Ex: a two-second motif, a struck Vibraphone E followed by a soft Cello D, with a 4-second decay tail. Used at the open and close of brand films, the welcome chime on the school app, and the start of school day announcements (optional).)','Logo sonore / motif audio : à finaliser. (Ex. : motif de deux secondes, vibraphone mi frappé suivi d’un ré doux au violoncelle, avec une résonance de 4 secondes. Utilisé à l’ouverture et à la clôture des films de marque, au carillon d’accueil de l’application et au début des annonces de la journée scolaire, optionnel.)'),
    L('Music library: Cinematic-editorial library tracks. Approved suppliers: Musicbed, Artlist, and a curated short list of independent composers. **No Hollywood “epic trailer” music. No royalty-free elevator music. No “ukulele + clap track” cliché.**','Bibliothèque musicale : pistes cinématographiques éditoriales. Fournisseurs approuvés : Musicbed, Artlist et une liste courte de compositeurs indépendants. **Pas de musique « bande-annonce épique » hollywoodienne. Pas de musique d’ascenseur libre de droits. Pas de cliché « ukulélé + clap ».**'),
    L('**Forbidden: Top-40 popular music in any official video. AI-generated music in any brand-expression video.**','**Interdit : musique Top-40 dans toute vidéo officielle. Musique générée par IA dans toute vidéo d’expression de marque.**')]}
  ]]}
 ]}
]},

{id:'p8', num:'09', title:L('Social Media','Réseaux sociaux'), intro:L('Each social platform serves a specific function. The brand does not maintain a presence on platforms where it does not have a defined function.','Chaque plateforme sociale remplit une fonction précise. La marque n’est pas présente sur une plateforme si cette présence n’a pas de fonction définie.'), sections:[
 {id:'8-0', kicker:L('9.0 · Social media','9.0 · Réseaux sociaux'), title:L('Social Media Systems','Systèmes de réseaux sociaux'), sub:L('Each social platform serves a specific function. The brand does not maintain a presence on platforms where it does not have a defined function.','Chaque plateforme sociale remplit une fonction précise. La marque n’est pas présente sur une plateforme si cette présence n’a pas de fonction définie.'), blocks:[
  {t:'table', head:[L('Platform','Plateforme'), L('Function','Fonction'), L('Cadence','Cadence'), L('Content Mix','Répartition des contenus')], rows:[
   ['Instagram (@lfkl_hevea)', L('Brand atmosphere, school life, parent community','Atmosphère de marque, vie de l’école, communauté des parents'), L('3 posts/week + 5 stories/week + 1 Reel/week.','3 publications/semaine + 5 stories/semaine + 1 Reel/semaine.'), L('50% school life documentary, 25% editorial / institutional, 15% community voices, 10% promotional (open days, deadlines).','50 % vie scolaire documentaire, 25 % éditorial / institutionnel, 15 % voix de la communauté, 10 % promotionnel (portes ouvertes, échéances).')],
   ['LinkedIn (Lycée Français de Kuala Lumpur LFKL)', L('Institutional credibility, employer brand, alumni network.','Crédibilité institutionnelle, marque employeur, réseau des anciens.'), L('2 posts/week.','2 publications/semaine.'), L('40% institutional news, 25% faculty thought leadership, 20% alumni stories, 15% recruitment.','40 % actualités institutionnelles, 25 % prises de parole des enseignants, 20 % récits d’anciens, 15 % recrutement.')],
   ['YouTube (LFKL)', L('Long-form content. The ‘show, don’t tell’ of the school.','Contenu long. Montrer l’école plutôt que l’expliquer.'), L('One major film per quarter. Short documentary pieces monthly.','Un film majeur par trimestre. Courts formats documentaires chaque mois.'), L('16:9 primary; 9:16 Shorts secondary.','16:9 principal ; Shorts 9:16 secondaires.')],
   ['TikTok', L('**Not currently maintained.** The platform’s tonal range is misaligned with the brand. Re-evaluate annually.','**Non animé actuellement.** Le ton de la plateforme est peu aligné avec la marque. Réévaluation annuelle.'), '', ''],
   ['Facebook', L('**Maintained for the parent community only.** Closed group, not a public page. New parents receive the link in the welcome packet.','**Maintenu uniquement pour la communauté des parents.** Groupe fermé, pas page publique. Les nouveaux parents reçoivent le lien dans le dossier d’accueil.'), '', ''],
   ['WhatsApp', L('**Used for transactional communication only.** Admissions and emergency notifications. Not a marketing channel.','**Utilisé seulement pour les communications transactionnelles.** Admissions et notifications d’urgence. Pas un canal marketing.'), '', '']]}
 ]},
 {id:'8-2', kicker:L('9.2 · Our tone of voice','9.2 · Notre ton de voix'), title:L('Our tone of Voice','Notre ton de voix'), blocks:[
  {t:'lead', text:L('FSKL writes like a thoughtful teacher speaking to thoughtful parents with substance, care and clarity.','FSKL écrit comme un enseignant réfléchi s’adressant à des parents attentifs, avec fond, attention et clarté.')},
  {w:[4,4,4], cols:[[
   {t:'h', text:L('Words we use','Mots que nous utilisons')},
   {t:'chips', tone:'do', items:L(['Formation','Excellence','Standard','Multilingual','Multicultural','Tricultural','international mindset','Eurocampus','sharing','openness','curiosity','engagement','since 1962'],['Formation','Excellence','Niveau','Multilingue','Multiculturel','Triculturel','esprit international','Eurocampus','transmission','ouverture','curiosité','engagement','depuis 1962'])}
  ],[
   {t:'h', text:L('Words we avoid','Mots que nous évitons')},
   {t:'chips', tone:'dont', items:['journey','world-class','cutting-edge','innovative','holistic','nurture','empower','21st-century skills']},
   {t:'note', text:L('Every avoided word is used by every competitor school in Kuala Lumpur. Avoiding them is how FSKL sounds like itself.','Chaque mot évité est utilisé par toutes les écoles concurrentes de Kuala Lumpur. Les éviter permet à FSKL de parler avec sa propre voix.')}
  ],[
   {t:'h', text:L('Archetype','Archétype')},
   {t:'list', style:'defs', items:[
    {title:L('The Sage','Le Sage'), text:L('Truth through knowledge. Primary.','La vérité par le savoir. Principal.')},
    {title:L('The Cultivator','Le Cultivateur'), text:L('Plants, prunes, and waits. Secondary.','Plante, taille et attend. Secondaire.')}]}
  ]]}
 ]}
]}
];
})();
