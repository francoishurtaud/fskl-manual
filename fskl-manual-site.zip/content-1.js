(function(){
var L=function(e,f){return {en:e,fr:f}};
var R='assets/raw/', C='assets/crop/';
window.FSKL_PARTS=window.FSKL_PARTS||{};
window.FSKL_PARTS.a=[
{id:'front', num:'', title:L('Front matter','Préambule'), sections:[
 {id:'about', kicker:L('Front matter','Préambule'), title:L('About this document','À propos de ce document'), blocks:[
  {w:[7,5], cols:[[
   {t:'lead', text:L('A brand manual is structure of an institution’s reputation. It makes the next ten years of leadership decisions easier.','Un manuel de marque structure la réputation d’une institution. Il rend plus simples les décisions de direction pour les dix prochaines années.')},
   {t:'p', text:L('This manual is built on a two strategic directions:','Ce manuel repose sur deux orientations stratégiques :')},
   {t:'list', style:'num', items:[
    L('FSKL is no longer simply a French school in Kuala Lumpur. It is evolving into a Eurocampus, where French, German, and English educational traditions share one campus, one daily life, and a coordinated pedagogical vision.','FSKL n’est plus seulement une école française à Kuala Lumpur. Elle évolue vers un Eurocampus, où les traditions éducatives française, allemande et anglaise partagent un même lieu, une même vie quotidienne et une vision pédagogique coordonnée.'),
    L('The school reaches maturity in welcoming the French expatriates community, the school needs to appeal to another cohort: locals & bi-nationals families.','L’école a atteint sa maturité auprès de la communauté expatriée française. Elle doit désormais s’adresser aussi à un autre public : les familles locales et binationale.')]},
   {t:'p', text:L('The identity system exists to make that position legible, durable, and difficult to dilute.','Ce système d’identité existe pour rendre ce positionnement lisible, durable et difficile à affaiblir.')}
  ],[
   {t:'images', cols:1, items:[{src:R+'p002_1.png', fit:'contain', h:120, bg:'#FFFFFF'}]},
   {t:'table', key:true, rows:[
    [L('Authoring framework','Cadre de rédaction'), L('2026 brand workshop outputs: Vision, Mission, Manifeste, Tone of Voice, Valeurs, Slogan.','Ateliers de marque 2026 : Vision, Mission, Manifeste, Ton de voix, Valeurs, Slogan.')],
    [L('Effective date','Date d’application'), L('2027 academic year onwards.','À partir de l’année scolaire 2027.')],
    [L('Review cycle','Cycle de révision'), L('Major review every 36 months; tactical updates quarterly.','Révision majeure tous les 36 mois ; mises à jour opérationnelles chaque trimestre.')],
    [L('Guideline Keeper','Garant des règles'), L('Office of the Director of Communications, FSKL.','Direction de la communication, FSKL.')],
    [L('Classification','Classification'), L('Internal: confidential to leadership, staff, and approved partners.','Interne : confidentiel, réservé à la direction, au personnel et aux partenaires autorisés.')]]}
  ]]}
 ]},
 {id:'layers', kicker:L('Front matter','Préambule'), title:L('One brand, built in two layers','Une seule marque, deux niveaux d’usage'), blocks:[
  {t:'cards', cols:2, items:[
   {label:L('Layer 1','Niveau 1'), title:L('Brand Expression','Expression de marque'), text:L('The professional layer that Communications, Admissions, leadership, and external agencies use. It can be ambitious, emotional, and editorially confident.','Le niveau professionnel utilisé par la communication, les admissions, la direction et les agences extérieures. Il peut être ambitieux, sensible et affirmé sur le plan éditorial.'), foot:L('Baskerville + Montserrat Alternates (word mark)','Baskerville + Montserrat Alternates (marque verbale)')},
   {dark:true, label:L('Layer 2','Niveau 2'), title:L('Operational School','École au quotidien'), text:L('The low-friction layer used by teachers and administrators every day. It must work in Google Slides, Canva, Microsoft Word, and on a printed permission slip with no design skill required.','Le niveau d’usage simple utilisé chaque jour par les enseignants et les équipes administratives. Il doit fonctionner dans Google Slides, Canva, Microsoft Word et sur une autorisation de sortie imprimée, sans compétence graphique particulière.'), foot:L('Baskerville + Arial. Installed everywhere','Baskerville + Arial. Installées partout')}]},
  {t:'note', text:L('The two layers share a single nervous system. A diploma printed by the Secrétariat Général and a campaign poster built by an external agency must feel as if they belong to the same institution because they do.','Les deux niveaux partagent un même système. Un diplôme imprimé par le Secrétariat Général et une affiche de campagne conçue par une agence extérieure doivent sembler appartenir à la même institution, parce que c’est le cas.')}
 ]}
]},

{id:'p1', num:'03', title:L('Brand Foundation','Fondements de la marque'), intro:L('Who FSKL is, what it believes, and the strategic position the entire identity exists to protect. Mission, vision, values, manifesto, the structure beneath every later decision.','Ce que FSKL est, ce qu’elle défend, et le positionnement stratégique que toute l’identité doit protéger. Mission, vision, valeurs, manifeste : la structure qui guide chaque décision à venir.'), sections:[
 {id:'1-1', kicker:L('3.1 · Brand overview','3.1 · Présentation de la marque'), title:L('An international French school, rooted in Europe, grown in Malaysia','Un établissement français international, ancré en Europe, grandi en Malaisie'), blocks:[
  {w:[7,5], cols:[[
   {t:'lead', text:L('FSKL, Lycée Français de Kuala Lumpur is an international French school accredited by the AEFE, serving children from maternelle through the baccalauréat.','FSKL, Lycée Français de Kuala Lumpur, est un établissement français international homologué par l’AEFE, qui accueille les élèves de la maternelle au baccalauréat.')},
   {t:'p', text:L('It operates on the Henri Fauconnier Campus and runs two named programmes alongside its core French curriculum: the Eurocampus, a tricultural European framework bringing French, German, and English traditions onto one site, and HEVEA, the early-years programme where roots are first put down.','Installé sur le campus Henri Fauconnier, l’établissement déploie deux programmes nommés aux côtés du Programme officiel de l’Éducation nationale française : l’Eurocampus, cadre européen triculturel réunissant les traditions française, allemande et anglaise sur un même site, et HEVEA, le programme des premières années, là où les racines se posent.')}
  ],[
   {t:'stats', items:[
    {big:'1962', text:L('Established · Kuala Lumpur','Création · Kuala Lumpur')},
    {big:'3', text:L('European traditions. One campus','Traditions européennes. Un seul campus')},
    {img:R+'p006_1.jpg', text:L('AEFE-accredited','Homologué AEFE')}]}
  ]]}
 ]},
 {id:'1-2', kicker:L('3.2 · Naming architecture','3.2 · Architecture des noms'), title:L('Four names, four jobs','Quatre noms, quatre rôles'), sub:L('The most common mistake in school branding is to blur them. This architecture is canonical and exhaustive.','L’erreur la plus fréquente, dans l’identité d’un établissement, consiste à les confondre. Cette architecture est la référence : elle est complète et non extensible.'), blocks:[
  {t:'cards', cols:4, items:[
   {num:'1', img:'assets/logo/wordmark.png', imgH:48, title:'FSKL', text:L('The brand monogram. Short, pronounceable, international. The everyday signature.','Le monogramme de marque. Court, prononçable, international. La signature du quotidien.')},
   {num:'2', img:'assets/logo/types.png', imgH:48, title:'French School Kuala Lumpur', text:L('The full institutional name. Legal, formal, and never translated.','Le nom institutionnel complet. Juridique, formel, et jamais traduit.')},
   {num:'3', display:'Henri Fauconnier', title:L('Henri Fauconnier Campus','Campus Henri Fauconnier'), text:L('The place. Named for the planter and Goncourt laureate who linked France to Malaya.','Le lieu. Nommé en référence au planteur et prix Goncourt qui relia la France à la Malaisie.')},
   {num:'4', dark:true, display:'Eurocampus & HEVEA', title:'Eurocampus & HEVEA', text:L('The programmes. Eurocampus carries the tricultural ambition; HEVEA carries the early years.','Les programmes. Eurocampus porte l’ambition triculturelle ; HEVEA porte les premières années.')}]},
  {t:'rule', text:L('One programme per artefact. A maternelle parent letter belongs to FSKL and uses the HEVEA signature; an admissions ad for the English section belongs to FSKL and uses the Eurocampus signature.','Un programme par support. Une lettre aux parents de maternelle relève de FSKL et utilise la signature HEVEA ; une annonce d’admissions pour la section anglaise relève de FSKL et utilise la signature Eurocampus.')}
 ]},
 {id:'1-3', kicker:L('3.3 · The Henri Fauconnier reference','3.3 · La référence Henri Fauconnier'), title:L('A French identity, taken root','Une identité française, enracinée'), blocks:[
  {w:[4,4,4], cols:[[
   {t:'images', cols:1, items:[{src:R+'p008_1.jpg', fit:'contain', h:540, cap:'Henri Fauconnier (1879–1973)'}]}
  ],[
   {t:'p', text:L('Henri Fauconnier (1879–1973) was a French planter who pioneered rubber plantations in Selangor in the early 20th century and won the 1930 Prix Goncourt for his novel Malaisie. Naming the campus after him is not nostalgia, it is a strategic anchor.','Henri Fauconnier (1879–1973) fut un planteur français qui contribua au développement des plantations d’hévéas au Selangor au début du XXe siècle et reçut le prix Goncourt en 1930 pour son roman Malaisie. Donner son nom au campus n’est pas un geste nostalgique : c’est un ancrage stratégique.')}
  ],[
   {t:'images', cols:1, items:[{src:'assets/logo/fav.png', fit:'contain', h:220, bg:'#FFFFFF'}]}
  ]]}
 ]},
 {id:'1-4', kicker:L('3.4 · Brand story','3.4 · Récit de marque'), title:L('We are rooted in Europe. **We are grown in Malaysia.**','Nous sommes enracinés en Europe. **Nous avons grandi en Malaisie.**'), blocks:[
  {w:[6,6], cols:[[
   {t:'lead', text:L('In 1962, a small French school opened in Kuala Lumpur to serve a handful of French families. More than sixty years later, it has become a permanent fixture of the city’s educational landscape.','En 1962, une petite école française ouvre à Kuala Lumpur pour accueillir quelques familles françaises. Plus de soixante ans plus tard, elle est devenue une présence durable dans le paysage éducatif de la ville.')},
   {t:'p', text:L('The families we serve come from many places and many traditions. What we share with them is a belief that excellence, an international mind, and an open disposition are built slowly and built to last.','Les familles que nous accueillons viennent de nombreux pays et de nombreuses traditions. Ce que nous partageons avec elles, c’est la conviction que l’excellence, l’esprit international et l’ouverture se construisent lentement et dans la durée.')}
  ],[
   {t:'images', cols:1, items:[{src:R+'p009_2.jpg', h:380, cap:L('The first school, Kuala Lumpur, 1960s','La première école, Kuala Lumpur, années 1960')}]}
  ]]}
 ]},
 {id:'1-5', kicker:L('3.5 · Mission statement','3.5 · Mission'), title:L('Help succeed, pass on, open up','Faire réussir, transmettre, ouvrir'), blocks:[
  {t:'cards', cols:3, items:[
   {num:'1', title:L('Help succeed','Faire réussir'), text:L('Guide every student with care towards the excellence that suits them and towards a path true to their own ambitions, in France and internationally.','Accompagner chaque élève avec bienveillance vers l’excellence qui lui correspond et vers un parcours fidèle à son projet, en France comme à l’international.')},
   {num:'2', title:L('Pass on','Transmettre'), text:L('Foster a love and mastery of the French language, and share the culture it carries.','Faire aimer et maîtriser la langue française, et faire découvrir la culture qu’elle porte.')},
   {num:'3', dark:true, title:L('Open up','Ouvrir'), text:L('Cultivate respect for each person and the meeting of languages and cultures, to educate citizens of the world.','Cultiver le respect de chacun et la rencontre des langues et des cultures, pour former des citoyens du monde.')}]}
 ]},
 {id:'1-6', kicker:L('3.6 · Vision statement','3.6 · Vision'), title:L('What we aspire to become','Ce que nous voulons devenir'), blocks:[
  {t:'statement', text:L('FSKL aims to be a French school of excellence, resolutely international, recognised for the quality of its teaching, the attention given to each student and the richness of its diversity. True to the values on which it was founded, it makes the meeting of cultures a strength in the service of every student’s success.','FSKL veut être un établissement français d’excellence, résolument international, reconnu pour la qualité de son enseignement, l’attention portée à chaque élève et la richesse de sa diversité. Fidèle aux valeurs qui le fondent, il fait de la rencontre des cultures une force au service de la réussite de tous.')}
 ]},
 {id:'1-7', kicker:L('3.7 · Core values','3.7 · Valeurs fondatrices'), title:L('Four values, one culture','Quatre valeurs, une culture'), blocks:[
  {t:'cards', cols:4, items:[
   {num:'1', icon:R+'p012_1.png', title:L('Excellence','L’excellence'), text:L('Nurture and develop every form of excellence: in our students, our staff, our infrastructure and our services.','Entretenir et développer toutes les formes d’excellence. Des élèves, des personnels, des infrastructures et des services.'), tags:'RIGUEUR · EXIGENCE · RAYONNEMENT'},
   {num:'2', icon:R+'p012_2.png', title:L('International Mindset','L’esprit international'), text:L('Offer our students an international experience and international perspectives.','Offrir à nos élèves une expérience et des perspectives internationales.'), tags:'OUVERTURE · CURIOSITÉ · DIALOGUE'},
   {num:'3', icon:R+'p012_3.png', title:L('Sharing','Le partage'), text:L('Bring French culture to life and share it, bringing people together around common values.','Faire vivre et partager la culture française, rassembler autour de valeurs communes.'), tags:'TRANSMISSION · BIENVEILLANCE · COMMUNAUTÉ'},
   {num:'4', icon:R+'p012_4.png', title:L('Openness','L’ouverture'), text:L('Respect other cultures and open ourselves to them.','Respecter et s’ouvrir aux autres cultures.'), tags:'RESPECT · INCLUSION'}]}
 ]},
 {id:'1-8', kicker:L('3.8 · Brand manifesto','3.8 · Manifeste de marque'), title:'Nous ne cherchons pas à aller vite. Nous cherchons à aller loin.', blocks:[
  {w:[3,9], cols:[[
   {t:'images', cols:1, items:[{src:'assets/logo/manifesto-hevea.png', fit:'contain', h:200}]}
  ],[
   {t:'lines', items:[
    L('We believe excellence is born of high standards and built over time.','Nous croyons que l’excellence naît de l’exigence et se construit dans la durée.'),
    L('We believe every student deserves to be recognised, supported and encouraged to surpass themselves.','Nous croyons que chaque élève mérite d’être reconnu, accompagné et encouragé à se dépasser.'),
    L('We believe languages open minds as much as doors.','Nous croyons que les langues ouvrent les esprits autant que les portes.'),
    L('We believe curiosity is born of experience and grows through contact with others.','Nous croyons que la curiosité naît de l’expérience et grandit au contact des autres.'),
    L('We believe the French school gives our students strong roots, and our international community opens the world to them.','Nous croyons que l’école française donne à nos élèves des racines solides, et que notre communauté internationale leur ouvre le monde.'),
    L('We believe success is measured not only by examinations, but also by the people our students become.','Nous croyons que la réussite ne se mesure pas seulement aux examens, mais aussi aux personnes que deviennent nos élèves.')]}
  ]]}
 ]},
 {id:'1-9', kicker:L('3.9 · Brand promise','3.9 · Promesse de marque'), title:L('What every family can expect when choosing FSKL.','Ce que chaque famille peut attendre en choisissant FSKL.'), blocks:[
  {t:'statement', size:'m', label:L('Family version','Version familles'), text:L('For your child, an education that combines French academic rigour with genuine international openness. They will be recognised, supported and encouraged to give their very best.','Pour votre enfant, une éducation qui allie l’exigence académique française à une véritable ouverture internationale. Il sera reconnu, accompagné et encouragé à donner le meilleur de lui-même.')},
  {t:'statement', size:'m', label:L('Institutional version','Version institutionnelle'), text:L('The high standards of the French school, the openness of an international community, and for every student, attentive support that helps them give their very best.','L’exigence de l’école française, l’ouverture d’une communauté internationale, et pour chaque élève un accompagnement attentif qui l’aide à donner le meilleur de lui-même.')}
 ]},
 {id:'1-10', kicker:L('3.10 · Positioning & USP','3.10 · Positionnement & singularité'), title:L('The master compass','La boussole principale'), blocks:[
  {w:[5,7], cols:[[
   {t:'statement', size:'s', label:L('Our positioning','Notre positionnement'), text:L('FSKL is a French school open to families of all nationalities seeking academic excellence in an international environment.','FSKL est une école française ouverte aux familles de toutes nationalités qui recherchent l’excellence académique dans un environnement international.')}
  ],[
   {t:'h', text:L('USP','Singularité')},
   {t:'list', style:'num', items:[
    {img:R+'p015_1.jpg', text:L('French academic excellence, guaranteed by AEFE, visible in pedagogy and results.','L’excellence académique française, garantie par l’AEFE, visible dans la pédagogie et les résultats.')},
    {img:R+'p015_2.png', text:L('An international, multicultural community life, present since 1962.','Une vie de communauté internationale et multiculturelle, présente depuis 1962.')},
    {img:R+'p015_3.png', text:L('The Eurocampus tricultural framework. FSKL’s particular contribution to the KL market.','Le cadre triculturel de l’Eurocampus. La contribution propre de FSKL au marché de Kuala Lumpur.')}]}
  ]]}
 ]},
 {id:'1-11', kicker:L('3.11 · Tagline / slogan system','3.11 · Système de signature'), title:L('One slogan','Une seule signature'), blocks:[
  {w:[5,7], cols:[[
   {t:'h', text:L('Slogan','Signature')},
   {t:'p', text:L('Logo system, prospectus cover, homepage hero.','Système de logo, couverture de brochure, visuel d’accueil du site.')}
  ],[
   {t:'statement', text:'L’excellence française.\n**Open to the World.**', center:true, box:true}
  ]]},
  {t:'rule', text:L('The slogan is bilingual by design. Use it exactly as written beside the logo. Never translate it, never combine it with another line.','La signature est bilingue par construction. L’utiliser telle quelle à côté du logo. Ne jamais la traduire, ne jamais l’associer à une autre formule.')}
 ]},
 {id:'1-12', kicker:L('3.12 · Emotional territory','3.12 · Territoire émotionnel'), title:L('We’re calm & confident','Calmes et sûrs de nous'), blocks:[
  {w:[5,7], cols:[[
   {t:'lead', text:L('FSKL occupies an emotional territory that is __calm__, __confident__, and __unsentimental__. It is not warm in the way a kindergarten brand is warm. It is warm in the way a serious teacher is warm: __present__, __attentive__, __demanding__, and on the child’s side.','FSKL occupe un territoire émotionnel __calme__, __confiant__, et __sans emphase__. Elle n’est pas chaleureuse à la manière d’une marque de maternelle. Elle l’est à la manière d’un enseignant sérieux : __présent__, __attentif__, __exigeant__, et du côté de l’enfant.')}
  ],[
   {t:'table', key:true, accent:true, rows:[
    [L('1. Cultivation','1. Culture'), L('Slow growth, deep roots, patience as a value. (Hevea metaphor.)','Croissance lente, racines profondes, patience comme valeur. (Métaphore de l’hévéa.)')],
    [L('2. Clarity','2. Clarté'), L('The absence of noise. A clean campus, a clean diploma, a clean conversation.','L’absence de bruit. Un campus clair, un diplôme clair, un échange clair.')],
    [L('3. Continuity','3. Continuité'), L('A sense that this institution has existed before us and will exist after us. (Est. 1962 is a fact, not a sticker.)','Le sentiment que l’institution existait avant nous et existera après nous. (Établi en 1962 est un fait, non un autocollant.)')]]}
  ]]}
 ]},
 {id:'1-13', kicker:L('3.13 · Brand personality','3.13 · Personnalité de marque'), title:L('Our Tone of Voice','Notre ton de voix'), blocks:[
  {t:'tone', items:[
   {l:L('Formal','Formel'), r:L('Casual','Familier'), pos:38, text:L('We are formal, but **not stiff.**','Nous sommes formels, mais **jamais raides.**')},
   {l:L('Traditional','Traditionnel'), r:L('Disruptive','En rupture'), pos:38, text:L('We are traditional, with **modern execution.**','Nous sommes traditionnels, avec une **exécution contemporaine.**')},
   {l:L('Reserved','Réservé'), r:L('Expressive','Expressif'), pos:62, text:L('We are reserved by default but **expressive on purpose.**','Nous sommes réservés par défaut, mais **expressifs quand il le faut.**')},
   {l:L('Serious','Sérieux'), r:L('Playful','Ludique'), pos:52, text:L('We are serious about education, **playful about life.**','Nous sommes sérieux dans l’éducation, **légers dans la vie.**')},
   {l:L('Premium','Prestigieux'), r:L('Accessible','Accessible'), pos:60, text:L('We are **accessible** to mid-market expat families.','Nous sommes **accessibles** aux familles expatriées de milieu intermédiaire.')}]}
 ]},
 {id:'1-16', kicker:L('3.14 · Strategic positioning statement','3.14 · Énoncé de positionnement stratégique'), title:L('Our Positioning','Notre positionnement'), blocks:[
  {t:'statement', size:'m', text:L('FSKL is a French school open to families of all nationalities seeking academic excellence in an international environment.\n\nAccredited by the French Ministry of National Education and a member of the AEFE network, the school follows the official French curriculum from preschool to the final year of secondary school.\n\nLocated on the Eurocampus in Kuala Lumpur, it offers its students a unique multicultural environment, while guaranteeing the rigour, continuity and recognised quality of the French education system.\n\nWe give our students strong academic foundations and an openness to the world. From this they draw the confidence they need to engage with others and succeed anywhere.','FSKL est une école française ouverte aux familles de toutes nationalités qui recherchent l’excellence académique dans un environnement international.\n\nHomologuée par le ministère de l’Éducation nationale et membre du réseau de l’AEFE, l’école suit les programmes officiels français de la maternelle à la terminale.\n\nImplantée sur l’Eurocampus de Kuala Lumpur, elle offre à ses élèves un environnement multiculturel unique, tout en leur garantissant la rigueur, la continuité et la qualité reconnues du système éducatif français.\n\nNous donnons à nos élèves des bases académiques solides et une ouverture sur le monde. Ils en tirent la confiance nécessaire pour dialoguer avec les autres et réussir partout.')},
  {t:'note', text:L('This statement is the master compass of the FSKL brand. Every campaign, every page of the website, every brochure is judged against it.','Cet énoncé est la boussole principale de la marque FSKL. Chaque campagne, chaque page du site, chaque brochure se juge à son regard.')}
 ]},
 {id:'1-17', kicker:L('3.15 · Elevator pitch','3.15 · Présentation brève'), title:L('Our Elevator Pitch','Notre présentation courte'), blocks:[
  {w:[4,8], cols:[[
   {t:'cards', cols:1, items:[{label:L('6 sec','6 s'), title:L('Parent in passing','Parent croisé rapidement'), quote:true, text:L('“We are the French school that became a Eurocampus, French BAC, German neighbour, and English cert on one site.”','« Nous sommes l’école française devenue Eurocampus : baccalauréat français, voisin allemand et certification anglaise sur un même site. »')}]}
  ],[
   {t:'cards', cols:1, items:[{label:L('30 sec','30 s'), title:L('Parent at open day','Parent lors d’une journée portes ouvertes'), quote:true, text:L('“We are the French School in Kuala Lumpur, AEFE-accredited, here since 1962. What’s specific to us is the Eurocampus: French, German, and English education integrated into shared school life, on one campus.\n\nChildren grow up genuinely multilingual and multicultural. Our graduates go on to universities in France, the UK, and beyond.\n\nThe campus is named for Henri Fauconnier, the French planter and Goncourt-winning author who first connected France and Malaysia.”','« Nous sommes la French School de Kuala Lumpur, homologuée AEFE, présente ici depuis 1962. Notre spécificité, c’est l’Eurocampus : les éducations française, allemande et anglaise intégrées dans une vie scolaire partagée, sur un même campus.\n\nLes enfants grandissent dans un environnement réellement multilingue et multiculturel. Nos diplômés poursuivent leurs études dans des universités en France, au Royaume-Uni et ailleurs.\n\nLe campus porte le nom d’Henri Fauconnier, planteur français et écrivain prix Goncourt, qui a relié la France et la Malaisie. »')}]}
  ]]}
 ]},
 {id:'1-19', kicker:L('3.16 · Messaging hierarchy','3.16 · Hiérarchie des messages'), title:L('A Clear Message','Un message clair'), sub:L('A clear messaging hierarchy keeps the brand from sounding scattered. All public-facing communication must respect this order.','Une hiérarchie claire des messages évite à la marque de paraître dispersée. Toute communication publique doit respecter cet ordre.'), blocks:[
  {t:'table', head:[L('Tier','Niveau'), L('Message','Message'), L('Where it leads','Où il prend le premier plan')], rows:[
   [L('1. Core','1. Cœur'), L('A demanding French education in Kuala Lumpur: l’excellence française, ailleurs.','Une éducation française exigeante à Kuala Lumpur : l’excellence française, ailleurs.'), L('Always present, often implicit.','Toujours présent, souvent implicite.')],
   [L('2. Differentiator','2. Différence'), L('The Eurocampus: French, German, and English educational traditions in shared school life.','L’Eurocampus : traditions éducatives française, allemande et anglaise dans une vie scolaire partagée.'), L('Leads in admissions, leadership communication, parent first-contact.','Premier plan pour les admissions, la communication de direction et les premiers contacts avec les parents.')],
   [L('3. Proof','3. Preuve'), L('Founded 1962. AEFE-accredited. Graduates accepted to leading universities in France, the UK, and beyond.','Fondée en 1962. Homologuée AEFE. Diplômés admis dans de grandes universités en France, au Royaume-Uni et ailleurs.'), L('Leads when credibility is the question.','Premier plan lorsque la crédibilité est l’enjeu.')],
   [L('4. Emotion','4. Émotion'), L('A school where children are formed and where they belong.','Une école où les enfants se construisent et trouvent leur place.'), L('Leads in storytelling, social media, parent testimonial content.','Premier plan pour les récits, les réseaux sociaux et les témoignages de parents.')],
   [L('5. Community','5. Communauté'), L('A multicultural community of families committed to long-form education.','Une communauté multiculturelle de familles engagées dans une éducation au long cours.'), L('Leads in community-building, alumni, retention.','Premier plan pour la vie de communauté, les anciens élèves et la fidélisation.')]]}
 ]},
 {id:'1-20', kicker:L('3.17 · Strategic tensions','3.17 · Tensions stratégiques'), title:L('Our tensions & contradictions','Nos tensions et contradictions'), sub:L('We know our tensions and resolve them, we do not pretend they don’t exist.','Nous connaissons nos tensions et nous les résolvons ; nous ne prétendons pas qu’elles n’existent pas.'), blocks:[
  {t:'table', head:[L('Tension','Tension'), L('How we resolve it','Notre réponse')], rows:[
   [L('French primacy vs tricultural equality','Primauté française vs égalité triculturelle'), L('French primacy is institutional (name, legal status, AEFE). Tricultural equality is operational and visual. Both appear, in that order.','La primauté française est institutionnelle (nom, statut juridique, AEFE). L’égalité triculturelle est opérationnelle et visuelle. Les deux apparaissent, dans cet ordre.')],
   [L('Tradition vs contemporaneity','Tradition vs contemporanéité'), L('We are traditional in pedagogy and contemporary in execution. The brand looks 2026; the school feels 1962.','Nous sommes traditionnels dans la pédagogie et contemporains dans l’exécution. La marque regarde 2026 ; l’école porte 1962.')],
   [L('Institutional gravity vs child warmth','Gravité institutionnelle vs chaleur envers l’enfant'), L('The brand surface is institutional. The brand interior, what happens in classrooms, is warm. We do not invert this. A “fun” institutional surface erodes trust.','La surface de la marque est institutionnelle. Son intérieur, ce qui se passe dans les classes, est chaleureux. Nous n’inversons pas cet ordre. Une surface institutionnelle trop « amusante » affaiblit la confiance.')],
   [L('AEFE compliance vs brand distinctiveness','Conformité AEFE vs singularité de marque'), L('AEFE has its own visual identity (its logo, its statements). We display it where required. It never overrides ours. We are a member of the network; we are not the network.','L’AEFE possède sa propre identité visuelle (logo, messages). Nous l’affichons lorsque c’est requis. Elle ne prend jamais le pas sur la nôtre. Nous sommes membre du réseau ; nous ne sommes pas le réseau.')]]}
  ]},
 {id:'1-21', kicker:L('3.18 · Audience architecture','3.18 · Architecture des publics'), title:L('Who we speak to','À qui nous nous adressons'), blocks:[
  {w:[6,6], cols:[[
   {t:'h', text:L('Primary Audiences','Publics principaux')},
   {t:'pyramid', items:[
    {title:L('Prospective families','Familles candidates'), text:L('French expatriates, international-professional and mixed-nationality families.','Expatriés français, familles internationales, professionnelles et binationales.')},
    {title:L('Current families','Familles actuelles'), text:L('The community that lives the brand daily, retention and advocacy.','La communauté qui vit la marque au quotidien : fidélisation et recommandation.')},
    {title:L('Students','Élèves'), text:L('From maternelle to terminale, the people the school forms.','De la maternelle à la terminale, les personnes que l’école forme.')}]}
  ],[
   {t:'h', text:L('Secondary Audiences','Publics secondaires')},
   {t:'cards', cols:2, items:[
    {title:L('Staff & teachers','Personnel & enseignants'), text:L('Daily producers of the operational layer.','Producteurs quotidiens du niveau opérationnel.')},
    {title:L('Alumni','Anciens élèves'), text:L('Student and Staff. A multi-decade relationship.','Élèves et personnel. Une relation sur plusieurs décennies.')},
    {title:L('Agencies & vendors','Agences & prestataires'), text:L('External executors of the brand.','Exécutants externes de la marque.')},
    {title:L('AEFE & partners','AEFE & partenaires'), text:L('The accreditation & institutional network.','Le réseau d’homologation et les partenaires institutionnels.')}]}
  ]]}
 ]},
]},

{id:'p3', num:'04', title:L('Logo System','Système de logos'), intro:L('A family of marks, not a single logo. Each member has a defined function, and the family is closed. No further marks may be added without the Brand Custodian.','Une famille de marques, et non un logo unique. Chaque membre a une fonction définie, et la famille est fermée. Aucun autre signe ne peut être ajouté sans l’accord du gardien de la marque.'), sections:[
 {id:'3-0', kicker:L('4.0 · Historic','4.0 · Historique'), title:L('Six decades, 5 Logotypes','Six décennies, 5 logotypes'), blocks:[
  {t:'cards', cols:5, items:[
   {img:R+'p027_3.jpg', imgH:110, label:L('1960s–1980s','Années 1960–1980'), title:L('Circular seal','Sceau circulaire'), text:L('Institutional, embassy-style, early expatriate school','Institutionnel, proche des codes d’ambassade, école expatriée des débuts')},
   {img:R+'p027_4.jpg', imgH:110, label:L('1980s–early 2000s','Années 1980–début 2000'), title:L('Watercolor hibiscus','Hibiscus aquarellé'), text:L('Strong local identity, informal, community-driven','Identité locale forte, informelle, portée par la communauté')},
   {img:R+'p027_5.jpg', imgH:110, label:'~2005–2010', title:L('First “FSKL” + kite','Premier « FSKL » + cerf-volant'), text:L('Matches new campus move','Correspond au déménagement vers le nouveau campus')},
   {img:R+'p027_1.png', imgH:110, label:'~2010–2026', title:L('Refined FSKL (Henri Fauconnier) + HEVEA','FSKL affiné (Henri Fauconnier) + HEVEA'), text:L('Modern system, expansion to primary','Système moderne, extension au primaire')},
   {img:'assets/logo/land.png', imgH:110, label:L('2027 onwards','À partir de 2027'), title:L('Eurocampus + IB Programme','Eurocampus + programme IB'), text:L('Cohesive, modular system','Système cohérent et modulaire'), current:true}]}
 ]},
 {id:'3-1', kicker:L('4.1 · The logo family','4.1 · La famille de logos'), title:L('Six lockups, one system','Six assemblages, un seul système'), blocks:[
  {t:'cards', cols:3, items:[
   {img:'assets/logo/portrait.png', imgH:150, label:'L1', title:L('Vertical','Vertical'), text:L('Master signature for diplomas, letterhead, signage.','Signature principale pour diplômes, papier à en-tête, signalétique.')},
   {img:'assets/logo/land.png', imgH:150, label:'L2', title:L('Horizontal A','Horizontal A'), text:L('Primary digital, web header, email, prospectus.','Usage numérique principal, en-tête web, e-mail, brochure.')},
   {img:'assets/logo/types.png', imgH:150, label:'L3', title:L('Horizontal B','Horizontal B'), text:L('No shield, footers, co-branding rows.','Sans écu, pieds de page, lignes de co-marquage.')},
   {img:'assets/logo/wordmark.png', imgH:150, label:'L4', title:L('Wordmark','Marque verbale'), text:L('Auxiliary, watermarks, motion, name tags.','Usage auxiliaire, filigranes, animation, badges nominatifs.')},
   {img:'assets/logo/emblem.png', imgH:150, label:'L5', title:L('Roundel / Seal','Médaillon / Sceau'), text:L('Ceremonial, diplomas, medals, foundation stones.','Usage cérémoniel, diplômes, médailles, pierres de fondation.')},
   {img:'assets/logo/fav.png', imgH:150, label:'L6', title:L('Shield','Écu'), text:L('Symbol-only, favicons, embroidery, monogram.','Symbole seul, favicons, broderie, monogramme.')}]},
  {t:'rule', text:L('Always use the official vector files from the asset library. Never re-export or screen-grab a lockup from this manual.','Toujours utiliser les fichiers vectoriels officiels de la bibliothèque d’actifs. Ne jamais réexporter ni capturer un assemblage depuis ce manuel.')}
 ]},
 {id:'3-2', kicker:L('4.2 · The symbol','4.2 · Le symbole'), title:L('The Symbol','Le symbole'), blocks:[
  {w:[4,8], cols:[[
   {t:'images', cols:1, items:[{src:'assets/logo/fav.png', fit:'contain', h:380, bg:'#FFFFFF'}]}
  ],[
   {t:'cards', cols:2, items:[
    {icon:'assets/logo/coq-navy.png', title:L('The Coq Gaulois','Le coq gaulois'), text:L('First read is the historical emblem of France since the Renaissance. It signals national heritage without being a flag: more refined, more pedagogically appropriate.\nA second symbolic meaning is of __resilience__.','La première lecture renvoie à l’emblème historique de la France depuis la Renaissance. Il signale l’héritage national sans être un drapeau : plus raffiné, plus juste pour une institution éducative.\nUne seconde signification symbolique est celle de la __résilience__.')},
    {icon:'assets/logo/hevea-navy.png', title:L('The Hevea','L’hévéa'), text:L('The rubber tree that built the human relationship between France and Malaysia, and the tree most associated with Henri Fauconnier.\nA second reading evokes a laurel wreath, a symbol of academic achievement.\nA third reading evokes growth and development.','L’arbre à caoutchouc qui a construit la relation humaine entre la France et la Malaisie, et l’arbre le plus associé à Henri Fauconnier.\nUne seconde lecture évoque la couronne de laurier, symbole de réussite académique.\nUne troisième lecture évoque la croissance et le développement.')},
    {icon:'assets/logo/fav.png', title:L('The Escutcheon','L’écusson'), text:L('Its rounded base signals European-continental, not Anglo-Saxon, heraldic lineage. Academic dignity without monarchic association. It frames the two symbols.','Sa base arrondie signale une filiation héraldique européenne continentale, et non anglo-saxonne. Une dignité académique sans association monarchique. Il encadre les deux symboles.')},
    {icon:R+'p029_5.png', title:L('The Signature Shades','Les ombres de signature'), text:L('The tail acts as an echo of the very graphic element of the legacy logo: the shades/flags feature in the recess area of both campuses.','La queue fait écho à un élément très graphique du logo historique : les ombres/drapeaux présents dans les zones de retrait des deux campus.')}]}
  ]]}
 ]},
 {id:'3-3', kicker:L('4.3 · The wordmark','4.3 · La marque verbale'), title:L('Institutional Wordmark','Marque verbale institutionnelle'), blocks:[
  {w:[6,6], cols:[[
   {t:'images', cols:1, items:[{src:'assets/logo/wordmark.png', fit:'contain', h:240, bg:'#FFFFFF', pad:48}]}
  ],[
   {t:'list', style:'defs', items:[
    {title:L('Set in Montserrat Alternates','Composée en Montserrat Alternates'), text:L('A geometric sans with subtly softened terminals. Used for the wordmark only, never as a brand typeface.','Une sans-serif géométrique aux terminaisons légèrement adoucies. Utilisée uniquement pour la marque verbale, jamais comme police de marque.')},
    {title:L('Geometric sans-serif','Sans-serif géométrique'), text:L('The vocabulary of European cultural institutions, not British boarding schools.','Le vocabulaire des institutions culturelles européennes, non celui des pensionnats britanniques.')},
    {title:L('Slight compression','Compression légère'), text:L('gives the wordmark institutional density.','donne à la marque verbale une densité institutionnelle.')},
    {title:L('Softened terminals','Terminaisons adoucies'), text:L('humanise the letterforms, warmth without losing seriousness.','humanisent les formes de lettres : de la chaleur sans perdre le sérieux.')},
    {title:L('The four-letter monogram','Le monogramme de quatre lettres'), text:L('is itself strategy, pronounceable for international audiences.','est déjà une stratégie : prononçable par les publics internationaux.')}]}
  ]]}
 ]},
 {id:'3-5', kicker:L('4.4 · Safe area','4.4 · Zone de protection'), title:L('Clear space & Construction Principles','Espace libre & principes de construction'), blocks:[
  {w:[5,7], cols:[[
   {t:'p', text:L('The exclusion zone is equal to __x__, measured from the outermost edges of the logo lockup. No typography, imagery, graphic elements, or page edges may enter this area.','La zone d’exclusion est égale à __x__, mesurée depuis les bords extérieurs de l’assemblage du logo. Aucun texte, visuel, élément graphique ou bord de page ne doit entrer dans cette zone.')},
   {t:'table', head:[L('Rule','Règle'), L('Specification','Spécification')], rows:[
    [L('Symbol Alignment','Alignement du symbole'), L('Crest vertically centred to wordmark block','Écu centré verticalement sur le bloc de la marque verbale')],
    [L('Primary Lockup','Assemblage principal'), L('Crest left, wordmark right','Écu à gauche, marque verbale à droite')],
    [L('Baseline Alignment','Alignement de base'), L('Descriptor and signature aligned to shared vertical grid','Descripteur et signature alignés sur une même grille verticale')],
    [L('Separation Rule','Règle de séparation'), L('Crest and wordmark separated by one grid module','Écu et marque verbale séparés par un module de grille')],
    [L('Clear Space','Espace libre'), L('Minimum clear space = x on all sides','Espace libre minimal = x sur tous les côtés')],
    [L('Scaling','Mise à l’échelle'), L('All elements scale proportionally, never independently','Tous les éléments se redimensionnent proportionnellement, jamais séparément')],
    [L('Typography','Typographie'), L('Wordmark must remain exactly as supplied artwork','La marque verbale doit rester exactement conforme aux fichiers fournis')],
    [L('Redrawing','Redessin'), L('Crest, wordmark and signature may not be reconstructed manually','L’écu, la marque verbale et la signature ne doivent pas être reconstruits manuellement')]]}
  ],[
   {t:'images', cols:1, items:[{src:C+'safe-area.png', fit:'contain', h:360, bg:'#FFFFFF'}]}
  ]]}
 ]},
 {id:'3-6', kicker:L('4.5 · Colour modes & backgrounds','4.5 · Modes couleur & fonds'), title:L('One treatment per background','Un traitement par fond'), blocks:[
  {t:'modes', items:[
   {label:L('White · Full colour','Blanc · Couleur'), bg:'#FFFFFF', img:'assets/logo/land.png', img2:'assets/logo/portrait.png', fg:'#111111'},
   {label:L('Vellum · Full colour','Vélin · Couleur'), bg:'#F9F1EC', img:'assets/logo/land.png', img2:'assets/logo/portrait.png', fg:'#111111'},
   {label:L('Navy · Reverse white','Bleu nuit · Blanc inversé'), bg:'#1D2845', img:'assets/logo/land-negblue.png', img2:'assets/logo/portrait-negblue.png', fg:'#FFFFFF'},
   {label:L('Mid-grey · Mono','Gris moyen · Monochrome'), bg:'#545250', img:'assets/logo/land-neg.png', img2:'assets/logo/portrait-neg.png', fg:'#FFFFFF'}]},
  {t:'p', text:L('On a navy background the reverse preserves the red comb and ochre wattle. On photography, the logo sits on negative space, never the busy portion of an image.','Sur un fond bleu nuit, la version inversée conserve la crête rouge et le barbillon ocre. Sur photographie, le logo se place dans un espace calme, jamais sur la partie chargée d’une image.')}
 ]},
 {id:'3-7', kicker:L('4.6 · Incorrect usage','4.6 · Usages interdits'), title:L('Never do this. Forbidden Treatments','Ne jamais faire ceci. Traitements interdits'), blocks:[
  {w:[6,6], cols:[[
   {t:'list', style:'dont', items:[
    L('Do not distort, stretch, or compress any lockup.','Ne pas déformer, étirer ni compresser un assemblage.'),
    L('Do not rotate the lockup off the horizontal axis.','Ne pas incliner l’assemblage hors de l’axe horizontal.'),
    L('Do not apply drop shadows, gradients, bevels, glows, or outlines to the lockup.','Ne pas appliquer d’ombres portées, dégradés, biseaux, halos ou contours à l’assemblage.'),
    L('Do not change the colours of the symbol, wordmark, or descriptors.','Ne pas modifier les couleurs du symbole, de la marque verbale ou des descripteurs.'),
    L('Do not rearrange the elements.','Ne pas réorganiser les éléments.'),
    L('Do not place the lockup on a busy photographic background without clear negative space.','Ne pas placer l’assemblage sur un fond photographique chargé sans espace négatif clair.'),
    L('Do not translate the descriptors. French School Kuala Lumpur is the only canonical wording, in all markets.','Ne pas traduire les descripteurs. French School Kuala Lumpur est la seule formulation de référence, sur tous les marchés.'),
    L('Do not create new lockups, sub-marks, or co-branded marks without approval from the Brand Custodian.','Ne pas créer de nouveaux assemblages, sous-marques ou marques co-signées sans validation du gardien de la marque.'),
    L('Do not use a screen-grabbed version of the logo. Always use the official vector files from the asset library.','Ne pas utiliser une capture d’écran du logo. Toujours utiliser les fichiers vectoriels officiels de la bibliothèque d’actifs.'),
    L('Do not crop, mask, or partially conceal the lockup for “artistic effect.”','Ne pas recadrer, masquer ou dissimuler partiellement l’assemblage pour un « effet artistique ».')]}
  ],[
   {t:'images', cols:1, items:[{src:C+'c34.jpg', fit:'contain', h:520, bg:'#F9F1EC', cross:true}]}
  ]]}
 ]},
 {id:'3-8', kicker:L('4.7 · Co-branding & partner logos','4.7 · Co-marquage & logos partenaires'), title:L('A clear hierarchy of marks','Une hiérarchie claire des marques'), blocks:[
  {t:'list', style:'check', items:[
   L('FSKL is always at least as large as any partner mark.','FSKL est toujours au moins aussi grand que toute marque partenaire.'),
   L('A vertical rule of 1.5 X separates marks, no “+” or “&” connector.','Un filet vertical de 1,5 X sépare les marques ; aucun « + » ni « & » de liaison.'),
   L('AEFE always appears to the right of FSKL, shown as accreditation, never as parent brand.','L’AEFE apparaît toujours à droite de FSKL, comme homologation, jamais comme marque mère.')]},
  {t:'images', cols:1, items:[{src:'assets/logo/master-aefe.png', fit:'contain', h:150, bg:'#FFFFFF', pad:12},{src:'assets/logo/master-rf-aefe.png', fit:'contain', h:150, bg:'#FFFFFF', pad:12, cap:L('Master lockup with the AEFE accreditor (top) and with République française and AEFE (bottom).','Assemblage principal avec l’AEFE (haut) et avec République française et AEFE (bas).')}]}
 ]},
 {id:'3-9', kicker:L('4.8 · Signage applications','4.8 · Applications signalétiques'), title:L('Logo Environment','Environnement du logo'), blocks:[
  {w:[5,7], cols:[[
   {t:'lead', size:'s', text:L('The strong sun of Malaysia affect printed colour. A desaturated logotype appears quickly dated and irrelevant. We want to avoid this decay and damaging perception. The rule is if __this is printed and will stay under the sun, go for raw material (metal, wood, stone), black print or dark blue.__','Le fort soleil de Malaisie altère les couleurs imprimées. Un logotype désaturé paraît vite daté et peu pertinent. Nous voulons éviter cette dégradation et la perception qu’elle entraîne. La règle est simple : __si le support est imprimé et reste au soleil, privilégier le matériau brut (métal, bois, pierre), l’impression noire ou le bleu foncé.__')},
   {t:'images', cols:1, items:[{src:R+'p036_1.png', fit:'contain', h:240, cross:true, cap:L('Sun-faded print: to avoid','Impression délavée au soleil : à éviter')}]}
  ],[
   {t:'images', cols:3, items:[{src:'assets/logo/land.png', fit:'contain', h:150, bg:'#FFFFFF'},{src:'assets/logo/land-black.png', fit:'contain', h:150, bg:'#FFFFFF'},{src:'assets/logo/emblem-black.jpg', fit:'contain', h:150, bg:'#FFFFFF'}]},
   {t:'table', plain:true, head:[L('Full Colour','Couleur'), L('Dark Blue / Black','Bleu foncé / noir'), L('Raw Material','Matériau brut')], rows:[
    [L('Website & social media','Site web & réseaux sociaux'), L('Wayfinding signage','Signalétique d’orientation'), L('Building signage','Signalétique bâtiment')],
    [L('Prospectus & brochures','Prospectus & brochures'), L('Vehicle livery','Marquage véhicules'), L('Entrance monuments','Monuments d’entrée')],
    [L('Reception areas','Espaces d’accueil'), L('Sports banners','Bannières sportives'), L('Foundation plaques','Plaques de fondation')],
    [L('Event graphics','Graphismes d’événement'), L('Outdoor graphics','Graphismes extérieurs'), L('Donor walls & plaques','Murs et plaques donateurs')]]}
  ]]}
 ]}
]}
];
})();
